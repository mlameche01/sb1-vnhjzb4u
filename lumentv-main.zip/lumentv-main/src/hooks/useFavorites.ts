import { useCallback, useEffect, useState } from "react";

export type FavoriteChannel = {
  slug: string; // route slug: name:claim_id
  name: string; // @handle
  title?: string;
  thumbnail?: string;
  addedAt: number;
};

const STORAGE_KEY = "lumen.favorite_channels.v1";
const EVENT = "lumen:favorites-changed";

function read(): FavoriteChannel[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as FavoriteChannel[]) : [];
  } catch {
    return [];
  }
}

function write(list: FavoriteChannel[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  window.dispatchEvent(new CustomEvent(EVENT));
}

export function useFavorites() {
  const [favorites, setFavorites] = useState<FavoriteChannel[]>(() => read());

  useEffect(() => {
    const sync = () => setFavorites(read());
    window.addEventListener(EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const isFavorite = useCallback(
    (slug: string) => favorites.some((f) => f.slug === slug),
    [favorites],
  );

  const add = useCallback((fav: Omit<FavoriteChannel, "addedAt">) => {
    const list = read();
    if (list.some((f) => f.slug === fav.slug)) return;
    write([{ ...fav, addedAt: Date.now() }, ...list]);
  }, []);

  const remove = useCallback((slug: string) => {
    write(read().filter((f) => f.slug !== slug));
  }, []);

  const toggle = useCallback((fav: Omit<FavoriteChannel, "addedAt">) => {
    const list = read();
    if (list.some((f) => f.slug === fav.slug)) {
      write(list.filter((f) => f.slug !== fav.slug));
    } else {
      write([{ ...fav, addedAt: Date.now() }, ...list]);
    }
  }, []);

  return { favorites, isFavorite, add, remove, toggle };
}
