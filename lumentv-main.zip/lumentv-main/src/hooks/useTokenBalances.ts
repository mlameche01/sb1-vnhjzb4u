import { useCallback, useEffect, useState } from "react";
import { ERC20_TOKENS, fromUnits, getErc20Balance, TokenKey } from "@/lib/evm";

export type TokenBalances = Partial<Record<TokenKey, string>>;

export function useTokenBalances(account: string | null) {
  const [balances, setBalances] = useState<TokenBalances>({});
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    if (!account) {
      setBalances({});
      return;
    }
    setLoading(true);
    try {
      const entries = await Promise.all(
        (Object.keys(ERC20_TOKENS) as TokenKey[]).map(async (key) => {
          try {
            const raw = await getErc20Balance(ERC20_TOKENS[key].address, account);
            return [key, fromUnits(raw, ERC20_TOKENS[key].decimals, 4)] as const;
          } catch {
            return [key, "—"] as const;
          }
        }),
      );
      const next: TokenBalances = {};
      for (const [k, v] of entries) next[k] = v;
      setBalances(next);
    } finally {
      setLoading(false);
    }
  }, [account]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { balances, loading, refresh };
}
