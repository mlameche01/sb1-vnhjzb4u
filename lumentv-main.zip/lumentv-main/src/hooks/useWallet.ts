import { useState, useCallback, useEffect } from "react";
import { ERC20_TOKENS } from "@/lib/evm";

const DZD_WATCH_KEY = "dzd_token_watched";

const XDC_TESTNET = {
  chainId: "0x33", // 51 decimal
  chainName: "XDC Apothem Testnet",
  nativeCurrency: { name: "TXDC", symbol: "TXDC", decimals: 18 },
  rpcUrls: ["https://erpc.apothem.network"],
  blockExplorerUrls: ["https://explorer.apothem.network"],
};

export interface WalletState {
  account: string | null;
  balance: string | null;
  chainId: string | null;
  connecting: boolean;
  error: string | null;
  connect: () => Promise<void>;
  disconnect: () => void;
  refreshBalance: () => Promise<void>;
}

export function useWallet(): WalletState {
  const [account, setAccount] = useState<string | null>(null);
  const [balance, setBalance] = useState<string | null>(null);
  const [chainId, setChainId] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getEth = () => (window as any).ethereum ?? null;

  const fetchBalance = useCallback(async (addr: string) => {
    const eth = getEth();
    if (!eth) return;
    try {
      const raw: string = await eth.request({
        method: "eth_getBalance",
        params: [addr, "latest"],
      });
      const txdc = Number(BigInt(raw)) / 1e18;
      setBalance(txdc.toFixed(4));
    } catch {
      setBalance(null);
    }
  }, []);

  const refreshBalance = useCallback(async () => {
    if (account) await fetchBalance(account);
  }, [account, fetchBalance]);

  const switchToXDC = useCallback(async () => {
    const eth = getEth();
    try {
      await eth.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: XDC_TESTNET.chainId }],
      });
    } catch (switchErr: any) {
      // 4902 = chain not added yet
      if (switchErr.code === 4902) {
        await eth.request({
          method: "wallet_addEthereumChain",
          params: [XDC_TESTNET],
        });
      } else {
        throw switchErr;
      }
    }
  }, []);

  const connect = useCallback(async () => {
    const eth = getEth();
    if (!eth) {
      setError("MetaMask non détecté. Installe l'extension.");
      return;
    }
    setConnecting(true);
    setError(null);
    try {
      const accounts: string[] = await eth.request({
        method: "eth_requestAccounts",
      });
      await switchToXDC();
      const currentChain: string = await eth.request({ method: "eth_chainId" });
      setChainId(currentChain);
      setAccount(accounts[0]);
      await fetchBalance(accounts[0]);

      // Proposer l'ajout du jeton DZD à MetaMask (une seule fois par navigateur)
      try {
        if (!localStorage.getItem(DZD_WATCH_KEY)) {
          const dzd = ERC20_TOKENS.DZD;
          await eth.request({
            method: "wallet_watchAsset",
            params: {
              type: "ERC20",
              options: {
                address: dzd.address,
                symbol: dzd.symbol,
                decimals: dzd.decimals,
              },
            },
          });
          localStorage.setItem(DZD_WATCH_KEY, "1");
        }
      } catch {
        // utilisateur a refusé ou wallet ne supporte pas — on ignore
      }
    } catch (err: any) {
      if (err.code === 4001) {
        setError("Connexion refusée par l'utilisateur.");
      } else {
        setError(err.message || "Erreur de connexion.");
      }
    } finally {
      setConnecting(false);
    }
  }, [fetchBalance, switchToXDC]);

  const disconnect = useCallback(() => {
    setAccount(null);
    setBalance(null);
    setChainId(null);
    setError(null);
  }, []);

  // Listen for account / chain changes
  useEffect(() => {
    const eth = getEth();
    if (!eth || typeof eth.on !== "function") return;

    const onAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        disconnect();
      } else {
        setAccount(accounts[0]);
        fetchBalance(accounts[0]);
      }
    };

    const onChainChanged = (id: string) => {
      setChainId(id);
      if (account) fetchBalance(account);
    };

    eth.on("accountsChanged", onAccountsChanged);
    eth.on("chainChanged", onChainChanged);

    return () => {
      if (typeof eth.removeListener === "function") {
        eth.removeListener("accountsChanged", onAccountsChanged);
        eth.removeListener("chainChanged", onChainChanged);
      }
    };
  }, [account, disconnect, fetchBalance]);

  return {
    account,
    balance,
    chainId,
    connecting,
    error,
    connect,
    disconnect,
    refreshBalance,
  };
}
