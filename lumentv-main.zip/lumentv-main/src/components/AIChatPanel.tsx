import { useState, useRef, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  X,
  Send,
  Bot,
  Loader2,
  Tv2,
  Search,
  Lightbulb,
  Radio,
  ChevronRight,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type Role = "user" | "assistant";

interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: Date;
}

interface AIChatPanelProps {
  /** Contrôle l'ouverture depuis le parent */
  open: boolean;
  onClose: () => void;
  /** Contexte optionnel : vidéos trending actuellement affichées */
  trendingTitles?: string[];
}

// ─── Suggestions rapides ──────────────────────────────────────────────────────

const QUICK_SUGGESTIONS = [
  { icon: Tv2,      label: "Vidéos trending en ce moment" },
  { icon: Search,   label: "Cherche des vidéos sur la technologie" },
  { icon: Lightbulb,label: "C'est quoi le réseau LBRY ?" },
  { icon: Radio,    label: "Recommande-moi des chaînes" },
];

// ─── System prompt ────────────────────────────────────────────────────────────

function buildSystemPrompt(trendingTitles?: string[]): string {
  const trendingSection =
    trendingTitles && trendingTitles.length > 0
      ? `\n\nVidéos actuellement en tendance sur la plateforme :\n${trendingTitles
          .slice(0, 15)
          .map((t, i) => `${i + 1}. ${t}`)
          .join("\n")}`
      : "";

  return `Tu es un assistant spécialisé pour LumenTV, une interface de streaming décentralisée basée sur le réseau LBRY/Odysee.

Tu peux aider l'utilisateur à :
- Comprendre ce qui est en tendance sur la plateforme
- Rechercher des vidéos ou chaînes par sujet ou intérêt
- Expliquer le fonctionnement du réseau LBRY/Odysee et sa philosophie de décentralisation
- Recommander des chaînes selon les goûts de l'utilisateur
- Répondre à des questions sur la censure, la liberté d'expression et les plateformes décentralisées

Règles :
- Réponds toujours en français sauf si l'utilisateur écrit dans une autre langue
- Sois concis, direct et utile
- Si tu recommandes des chaînes ou vidéos, précise qu'elles sont disponibles sur Odysee/LBRY
- Ne prétends pas avoir accès en temps réel à la base de données LBRY, mais utilise le contexte fourni
- Tu peux suggérer à l'utilisateur d'utiliser la barre de recherche de l'application pour des recherches précises
${trendingSection}`;
}

// ─── Appel via Lovable AI (edge function) ─────────────────────────────────────

async function callAI(
  messages: { role: Role; content: string }[],
  systemPrompt: string
): Promise<string> {
  const { data, error } = await supabase.functions.invoke("chat", {
    body: { messages, systemPrompt },
  });

  if (error) {
    throw new Error(error.message ?? "Erreur de l'assistant");
  }
  if (data?.error) {
    throw new Error(data.error);
  }
  return data?.content ?? "";
}

// ─── Composant principal ──────────────────────────────────────────────────────

export default function AIChatPanel({
  open,
  onClose,
  trendingTitles,
}: AIChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Scroll automatique vers le bas
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Focus sur l'input à l'ouverture
  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 300);
  }, [open]);

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed || loading) return;

      const userMsg: Message = {
        id: crypto.randomUUID(),
        role: "user",
        content: trimmed,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      setLoading(true);

      try {
        const history = [...messages, userMsg].map((m) => ({
          role: m.role,
          content: m.content,
        }));

        const reply = await callAI(
          history,
          buildSystemPrompt(trendingTitles)
        );

        setMessages((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            role: "assistant",
            content: reply,
            timestamp: new Date(),
          },
        ]);
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : "Erreur inconnue";
        setMessages((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            role: "assistant",
            content: `❌ Erreur : ${errorMessage}. Vérifie ta connexion et réessaie.`,
            timestamp: new Date(),
          },
        ]);
      } finally {
        setLoading(false);
      }
    },
    [loading, messages, trendingTitles]
  );

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const formatTime = (d: Date) =>
    d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <>
      {/* Overlay mobile */}
      {open && (
        <div
          className="fixed inset-0 z-30 bg-black/40 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Panneau latéral */}
      <aside
        className={`
          fixed right-0 top-0 z-40 flex h-full w-full flex-col
          border-l border-border/60 bg-background/95 shadow-2xl backdrop-blur-xl
          transition-transform duration-300 ease-in-out
          sm:w-[420px]
          ${open ? "translate-x-0" : "translate-x-full"}
        `}
      >
        {/* ── En-tête ── */}
        <div className="flex shrink-0 items-center justify-between border-b border-border/60 px-4 py-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 ring-1 ring-primary/30">
              <Bot className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold leading-none">Assistant LumenTV</p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Spécialisé LBRY / Odysee
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-muted-foreground transition hover:bg-card hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* ── Corps ── */}
        <div className="flex flex-1 flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">

            {/* Message de bienvenue */}
            {messages.length === 0 && (
              <div className="space-y-4">
                <div className="rounded-xl border border-border/60 bg-card/60 p-4">
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    👋 Bonjour ! Je suis ton assistant pour explorer{" "}
                    <span className="text-primary font-medium">LumenTV</span>.
                    Je peux t'aider à trouver des vidéos, comprendre le réseau
                    LBRY, ou recommander des chaînes.
                  </p>
                </div>

                {/* Suggestions rapides */}
                <div className="space-y-2">
                  <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                    Suggestions
                  </p>
                  {QUICK_SUGGESTIONS.map(({ icon: Icon, label }) => (
                    <button
                      key={label}
                      onClick={() => sendMessage(label)}
                      className="group flex w-full items-center gap-3 rounded-lg border border-border/60 bg-card/40 px-3 py-2.5 text-left text-sm text-muted-foreground transition hover:border-primary/40 hover:bg-primary/5 hover:text-foreground"
                    >
                      <Icon className="h-3.5 w-3.5 shrink-0 text-primary/60 transition group-hover:text-primary" />
                      <span className="flex-1">{label}</span>
                      <ChevronRight className="h-3 w-3 opacity-0 transition group-hover:opacity-100" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Messages */}
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${
                  msg.role === "user" ? "flex-row-reverse" : "flex-row"
                }`}
              >
                {/* Avatar */}
                {msg.role === "assistant" && (
                  <div className="mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 ring-1 ring-primary/20">
                    <Bot className="h-3 w-3 text-primary" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] space-y-1 ${
                    msg.role === "user" ? "items-end" : "items-start"
                  } flex flex-col`}
                >
                  <div
                    className={`rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "rounded-tr-sm bg-primary text-primary-foreground"
                        : "rounded-tl-sm border border-border/60 bg-card/80 text-foreground"
                    }`}
                    style={{ whiteSpace: "pre-wrap", wordBreak: "break-word" }}
                  >
                    {msg.content}
                  </div>
                  <span className="px-1 text-[10px] text-muted-foreground/60">
                    {formatTime(msg.timestamp)}
                  </span>
                </div>
              </div>
            ))}

            {/* Indicateur de frappe */}
            {loading && (
              <div className="flex items-center gap-2.5">
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 ring-1 ring-primary/20">
                  <Bot className="h-3 w-3 text-primary" />
                </div>
                <div className="flex items-center gap-1.5 rounded-2xl rounded-tl-sm border border-border/60 bg-card/80 px-3.5 py-2.5">
                  <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
                  <span className="text-xs text-muted-foreground">
                    En train de répondre…
                  </span>
                </div>
              </div>
            )}

            <div ref={bottomRef} />
          </div>

          {/* ── Zone de saisie ── */}
          <div className="shrink-0 border-t border-border/60 p-3">
            {messages.length > 0 && (
              <button
                onClick={() => setMessages([])}
                className="mb-2 text-xs text-muted-foreground/60 transition hover:text-muted-foreground"
              >
                Effacer la conversation
              </button>
            )}
            <div className="flex items-end gap-2 rounded-xl border border-border/60 bg-card/60 px-3 py-2 ring-primary/40 focus-within:ring-2 transition">
              <textarea
                ref={inputRef}
                rows={1}
                value={input}
                onChange={(e) => {
                  setInput(e.target.value);
                  // Auto-resize
                  e.target.style.height = "auto";
                  e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
                }}
                onKeyDown={handleKeyDown}
                placeholder="Pose ta question…"
                disabled={loading}
                className="flex-1 resize-none bg-transparent text-sm outline-none placeholder:text-muted-foreground/50 disabled:opacity-50"
                style={{ minHeight: "24px", maxHeight: "120px" }}
              />
              <button
                onClick={() => sendMessage(input)}
                disabled={loading || !input.trim()}
                className="mb-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground transition hover:opacity-90 disabled:opacity-30"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </div>
            <p className="mt-1.5 text-center text-[10px] text-muted-foreground/40">
              Entrée pour envoyer · Maj+Entrée pour saut de ligne
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}
