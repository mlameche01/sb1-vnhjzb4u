import { Flame, Search, Compass, Radio, Sparkles, Heart, User, Copy, Check, Wallet } from "lucide-react";
import { useState } from "react";
import { useFavorites } from "@/hooks/useFavorites";
import { thumbnail } from "@/lib/lbry";
import { NavLink } from "@/components/NavLink";
import { toast } from "@/hooks/use-toast";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const items = [
  { title: "Trending", url: "/", icon: Flame },
  { title: "Search", url: "/search", icon: Search },
  { title: "Favorites", url: "/favorites", icon: Heart },
  { title: "Wallet", url: "/wallet", icon: Wallet },
];

const info = [
  { title: "About LBRY", url: "https://lbry.tech", icon: Compass, external: true },
  { title: "Odysee", url: "https://odysee.com", icon: Radio, external: true },
];

const DONATION_ADDRESS = "0xea99BD1cdd9A5067CDc19506B59De5B29631DFD5";

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { favorites } = useFavorites();
  const [copied, setCopied] = useState(false);

  async function copyAddress() {
    try {
      await navigator.clipboard.writeText(DONATION_ADDRESS);
      setCopied(true);
      toast({ title: "Address copied", description: "Thank you for your support!" });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ title: "Copy failed", description: DONATION_ADDRESS });
    }
  }

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">
      <SidebarHeader className="border-b border-sidebar-border">
        <NavLink to="/" className="flex items-center gap-2 px-2 py-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-primary shadow-glow-sm">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="flex flex-col">
              <span className="font-display text-lg font-bold leading-none tracking-tight text-glow">
                Lumen
              </span>
              <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                decentralized
              </span>
            </div>
          )}
        </NavLink>
      </SidebarHeader>

      <SidebarContent className="scrollbar-thin">
        <SidebarGroup>
          <SidebarGroupLabel className="font-mono text-[10px] uppercase tracking-widest">
            Discover
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      end
                      className="group transition-smooth hover:bg-sidebar-accent"
                      activeClassName="bg-sidebar-accent text-primary font-medium shadow-glow-sm"
                    >
                      <item.icon className="h-4 w-4 shrink-0 transition-smooth group-hover:text-primary" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {favorites.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel className="font-mono text-[10px] uppercase tracking-widest">
              Favorites
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {favorites.slice(0, 8).map((fav) => {
                  const thumb = fav.thumbnail ? thumbnail(fav.thumbnail) : "";
                  return (
                    <SidebarMenuItem key={fav.slug}>
                      <SidebarMenuButton asChild>
                        <NavLink
                          to={`/channel/${fav.slug}`}
                          className="group transition-smooth hover:bg-sidebar-accent"
                          activeClassName="bg-sidebar-accent text-primary font-medium shadow-glow-sm"
                        >
                          {thumb ? (
                            <img
                              src={thumb}
                              alt={fav.name}
                              className="h-4 w-4 shrink-0 rounded-full border border-primary/30 object-cover"
                            />
                          ) : (
                            <User className="h-4 w-4 shrink-0 transition-smooth group-hover:text-primary" />
                          )}
                          {!collapsed && (
                            <span className="truncate">{fav.title || fav.name}</span>
                          )}
                        </NavLink>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        <SidebarGroup>
          <SidebarGroupLabel className="font-mono text-[10px] uppercase tracking-widest">
            Network
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {info.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noreferrer"
                      className="group flex items-center gap-2 transition-smooth hover:bg-sidebar-accent"
                    >
                      <item.icon className="h-4 w-4 shrink-0 transition-smooth group-hover:text-primary" />
                      {!collapsed && <span>{item.title}</span>}
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {!collapsed ? (
          <div className="mx-3 mt-auto mb-3 space-y-3">
            <div className="rounded-lg border border-primary/30 bg-gradient-to-br from-primary/10 to-primary/5 p-3 shadow-glow-sm">
              <div className="mb-1.5 flex items-center gap-1.5">
                <Wallet className="h-3.5 w-3.5 text-primary" />
                <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
                  Support Lumen
                </span>
              </div>
              <p className="mb-2 text-xs text-muted-foreground">
                Help keep this project free and independent. Donate via EVM (ETH, BNB, Polygon...).
              </p>
              <button
                onClick={copyAddress}
                className="group flex w-full items-center gap-1.5 rounded-md border border-border/60 bg-background/60 px-2 py-1.5 font-mono text-[10px] text-muted-foreground transition-smooth hover:border-primary/60 hover:text-primary"
                title={DONATION_ADDRESS}
              >
                <span className="truncate">{DONATION_ADDRESS}</span>
                {copied ? (
                  <Check className="h-3 w-3 shrink-0 text-primary" />
                ) : (
                  <Copy className="h-3 w-3 shrink-0 transition-smooth group-hover:text-primary" />
                )}
              </button>
            </div>
            <div className="rounded-lg border border-sidebar-border bg-sidebar-accent/40 p-3">
              <div className="mb-1 flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary shadow-glow-sm" />
                <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
                  Live
                </span>
              </div>
              <p className="text-xs text-muted-foreground">
                Streaming from the LBRY peer-to-peer network. No accounts, no tracking.
              </p>
            </div>
          </div>
        ) : (
          <button
            onClick={copyAddress}
            className="mx-auto mt-auto mb-3 flex h-8 w-8 items-center justify-center rounded-lg border border-primary/30 bg-primary/10 text-primary transition-smooth hover:bg-primary/20 hover:shadow-glow-sm"
            title="Support Lumen (EVM)"
          >
            <Wallet className="h-4 w-4" />
          </button>
        )}
      </SidebarContent>
    </Sidebar>
  );
}
