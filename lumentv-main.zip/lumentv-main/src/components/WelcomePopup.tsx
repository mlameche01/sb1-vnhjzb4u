import { useEffect, useState } from "react";
import { X, Play } from "lucide-react";

const WELCOME_VIDEO_URL =
  "https://odysee.com/%24/embed/%40imarat-el-djazair%3A2%2F%D8%AA%D9%85%D9%88%D9%8A%D9%84_%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF_%D8%B5%D9%86%D8%A7%D8%B9_%D8%A7%D9%84%D9%85%D8%AD%D8%AA%D9%88%D9%89%3Ac?r=74d88JTmQAX8KCoN7okkpBJAiYnbUbmo";

export default function WelcomePopup() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    // Afficher une seule fois par session
    const seen = sessionStorage.getItem("welcome_seen");
    if (!seen) {
      const t = setTimeout(() => setOpen(true), 600);
      return () => clearTimeout(t);
    }
  }, []);

  const handleClose = () => {
    sessionStorage.setItem("welcome_seen", "1");
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
    >
      {/* Fond sombre flou */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={handleClose}
      />

      {/* Fenêtre modale */}
      <div className="relative z-10 w-full max-w-2xl rounded-2xl border border-primary/30 bg-card/95 shadow-2xl shadow-primary/10 backdrop-blur-md">

        {/* En-tête */}
        <div className="flex items-center justify-between border-b border-border/40 px-5 py-4">
          <div className="flex items-center gap-2">
            <Play className="h-4 w-4 fill-primary text-primary" />
            <span className="font-mono text-xs uppercase tracking-widest text-primary">
              Message de bienvenue
            </span>
          </div>
          <button
            onClick={handleClose}
            className="rounded-full border border-border/60 bg-card/60 p-1.5 text-muted-foreground transition hover:border-primary/60 hover:text-primary"
            aria-label="Fermer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Vidéo intégrée */}
        <div className="aspect-video w-full overflow-hidden">
          <iframe
            src={WELCOME_VIDEO_URL}
            className="h-full w-full"
            allowFullScreen
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            title="Message de bienvenue Lumen TV"
          />
        </div>

        {/* Pied de page */}
        <div className="flex items-center justify-between border-t border-border/40 px-5 py-3">
          <p className="text-xs text-muted-foreground">
            Lumen TV — Soutien Créateurs
          </p>
          <button
            onClick={handleClose}
            className="rounded-lg border border-border/60 bg-card/60 px-4 py-1.5 text-xs font-medium text-muted-foreground transition hover:border-primary/60 hover:text-primary"
          >
            Continuer →
          </button>
        </div>
      </div>
    </div>
  );
}
