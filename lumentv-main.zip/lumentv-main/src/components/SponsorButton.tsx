import { useState } from "react";
import { Heart, Loader2, CheckCircle2, AlertCircle, Wallet, ClipboardPaste } from "lucide-react";
import { ERC20_TOKENS, toUnits, transferErc20 } from "@/lib/evm";
import { useWallet } from "@/hooks/useWallet";

interface SponsorButtonProps {
  /** Nom affiché du créateur */
  creatorName?: string;
}

const PRESET_AMOUNTS = ["5", "10", "50", "100"];

type Status = "idle" | "connecting" | "pending" | "success" | "error";

function isValidEVMAddress(addr: string): boolean {
  return /^0x[0-9a-fA-F]{40}$/.test(addr.trim());
}

export default function SponsorButton({ creatorName }: SponsorButtonProps) {
  const wallet = useWallet();
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("10");
  const [manualAddress, setManualAddress] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [txHash, setTxHash] = useState<string | null>(null);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  const dzd = ERC20_TOKENS.DZD;
  const resolvedAddress = manualAddress.trim();
  const addressValid = isValidEVMAddress(resolvedAddress);

  async function handlePaste() {
    try {
      const text = await navigator.clipboard.readText();
      setManualAddress(text.trim());
    } catch {
      // Clipboard non disponible — l'utilisateur colle manuellement
    }
  }

  async function handleSponsor() {
    setErrMsg(null);
    setTxHash(null);

    if (!addressValid) {
      setErrMsg("Adresse EVM invalide (doit commencer par 0x…).");
      return;
    }

    // 1. Connecter le wallet si pas encore connecté
    if (!wallet.account) {
      setStatus("connecting");
      await wallet.connect();
      if (!wallet.account) {
        setStatus("error");
        setErrMsg("Connexion au wallet annulée.");
        return;
      }
    }

    // 2. Envoyer les DZD
    const parsedAmount = parseFloat(amount);
    if (!parsedAmount || parsedAmount <= 0) {
      setErrMsg("Montant invalide.");
      return;
    }

    setStatus("pending");
    try {
      const amountUnits = toUnits(amount, dzd.decimals);
      const hash = await transferErc20(
        dzd.address,
        resolvedAddress,
        amountUnits,
        wallet.account,
      );
      setTxHash(hash);
      setStatus("success");
    } catch (err: any) {
      setStatus("error");
      if (err.code === 4001) {
        setErrMsg("Transaction annulée par l'utilisateur.");
      } else {
        setErrMsg(err.message || "Erreur lors de l'envoi.");
      }
    }
  }

  function reset() {
    setStatus("idle");
    setTxHash(null);
    setErrMsg(null);
    setManualAddress("");
    setOpen(false);
  }

  return (
    <>
      {/* ── Bouton principal ── */}
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-primary/90 to-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-glow-sm transition hover:opacity-90 active:scale-95"
      >
        <Heart className="h-4 w-4" />
        Sponsoriser le créateur
      </button>

      {/* ── Modal ── */}
      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
          onClick={(e) => { if (e.target === e.currentTarget) reset(); }}
        >
          <div className="w-full max-w-sm rounded-2xl border border-border/60 bg-card shadow-xl">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
              <div className="flex items-center gap-2">
                <Heart className="h-4 w-4 text-primary" />
                <span className="font-semibold text-sm">Sponsoriser</span>
                {creatorName && (
                  <span className="text-xs text-muted-foreground">@{creatorName}</span>
                )}
              </div>
              <button
                onClick={reset}
                className="rounded-full p-1 text-muted-foreground transition hover:text-foreground"
              >
                ✕
              </button>
            </div>

            <div className="px-5 py-5 space-y-4">

              {/* ── Succès ── */}
              {status === "success" && (
                <div className="space-y-3">
                  <div className="flex flex-col items-center gap-2 rounded-xl border border-green-500/30 bg-green-500/10 px-4 py-4 text-center">
                    <CheckCircle2 className="h-8 w-8 text-green-400" />
                    <p className="font-semibold text-green-400">Transaction envoyée !</p>
                    <p className="text-xs text-muted-foreground">
                      {amount} DZD → <span className="font-mono">{resolvedAddress.slice(0, 8)}…{resolvedAddress.slice(-6)}</span>
                    </p>
                  </div>
                  {txHash && (
                    <a
                      href={`https://explorer.apothem.network/txs/${txHash}`}
                      target="_blank"
                      rel="noreferrer"
                      className="block text-center font-mono text-[11px] text-primary underline-offset-2 hover:underline"
                    >
                      Voir sur l'explorateur →
                    </a>
                  )}
                  <button
                    onClick={reset}
                    className="w-full rounded-lg border border-border/60 bg-card/60 px-4 py-2 text-sm text-muted-foreground transition hover:text-foreground"
                  >
                    Fermer
                  </button>
                </div>
              )}

              {/* ── Formulaire ── */}
              {status !== "success" && (
                <>
                  {/* Adresse destinataire */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-widest font-mono">
                      Adresse EVM du créateur
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={manualAddress}
                        onChange={(e) => setManualAddress(e.target.value)}
                        placeholder="0x…"
                        spellCheck={false}
                        className={`w-full rounded-lg border bg-background/40 px-3 py-2.5 pr-10 font-mono text-xs text-foreground outline-none transition focus:ring-1 ${
                          manualAddress && !addressValid
                            ? "border-destructive/60 focus:border-destructive focus:ring-destructive/30"
                            : addressValid
                            ? "border-green-500/50 focus:border-green-500/70 focus:ring-green-500/20"
                            : "border-border/60 focus:border-primary/60 focus:ring-primary/30"
                        }`}
                      />
                      <button
                        onClick={handlePaste}
                        title="Coller depuis le presse-papier"
                        className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground transition hover:text-primary"
                      >
                        <ClipboardPaste className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    {manualAddress && !addressValid && (
                      <p className="text-[11px] text-destructive">
                        Format invalide — 42 caractères commençant par 0x.
                      </p>
                    )}
                  </div>

                  {/* Presets montant */}
                  <div className="grid grid-cols-4 gap-2">
                    {PRESET_AMOUNTS.map((p) => (
                      <button
                        key={p}
                        onClick={() => setAmount(p)}
                        className={`rounded-lg border py-2 text-sm font-mono font-semibold transition ${
                          amount === p
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border/60 bg-card/40 text-muted-foreground hover:border-primary/40 hover:text-foreground"
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>

                  {/* Montant libre */}
                  <div className="relative">
                    <input
                      type="number"
                      min="0.01"
                      step="0.01"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="w-full rounded-lg border border-border/60 bg-background/40 px-4 py-2.5 pr-16 font-mono text-sm text-foreground outline-none focus:border-primary/60 focus:ring-1 focus:ring-primary/30"
                      placeholder="Montant"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 font-mono text-xs font-semibold text-primary">
                      DZD
                    </span>
                  </div>

                  {/* Wallet connecté */}
                  {wallet.account && (
                    <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Wallet className="h-3.5 w-3.5" />
                      <span className="font-mono">{wallet.account.slice(0, 6)}…{wallet.account.slice(-4)}</span>
                    </p>
                  )}

                  {/* Erreur */}
                  {errMsg && (
                    <div className="flex items-center gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                      <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                      {errMsg}
                    </div>
                  )}

                  {/* Bouton envoyer */}
                  <button
                    onClick={handleSponsor}
                    disabled={!addressValid || status === "pending" || status === "connecting"}
                    className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {status === "pending" || status === "connecting" ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        {status === "connecting" ? "Connexion…" : "Envoi en cours…"}
                      </>
                    ) : (
                      <>
                        <Heart className="h-4 w-4" />
                        Envoyer {amount || "…"} DZD
                      </>
                    )}
                  </button>

                  <p className="text-center text-[11px] text-muted-foreground">
                    Réseau XDC Apothem · Contrat DZD
                  </p>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
