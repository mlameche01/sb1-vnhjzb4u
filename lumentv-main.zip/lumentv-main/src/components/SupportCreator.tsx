import React from "react";

export default function SupportCreator() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Support Créateur</h1>

      <p>Vous pouvez soutenir le créateur via Credimobil :</p>

      <ul>
        <li><strong>Mobilis :</strong> *600#</li>
        <li><strong>Djezzy :</strong> *720#</li>
        <li><strong>Ooredoo :</strong> *151#</li>
      </ul>

      <p>
        Suivez les instructions USSD pour transférer du crédit vers le numéro du créateur.
      </p>
    </div>
  );
}
