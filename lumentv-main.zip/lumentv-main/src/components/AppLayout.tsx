import { Outlet, useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import { useState, FormEvent } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { Input } from "@/components/ui/input";

export default function AppLayout() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  function onSearch(e: FormEvent) {
    e.preventDefault();
    if (!q.trim()) return;
    navigate(`/search?q=${encodeURIComponent(q.trim())}`);
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <AppSidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-border bg-background/80 px-3 backdrop-blur-xl md:px-6">
            <SidebarTrigger className="text-muted-foreground hover:text-primary" />
            <form onSubmit={onSearch} className="relative ml-1 flex-1 max-w-2xl">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search the decentralized network..."
                className="h-9 border-border/60 bg-card/60 pl-9 font-mono text-sm placeholder:text-muted-foreground/60 focus-visible:border-primary focus-visible:ring-primary/20"
              />
            </form>
            <div className="ml-auto hidden items-center gap-1.5 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 md:flex">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary shadow-glow-sm" />
              <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
                LBRY Network
              </span>
            </div>
          </header>
          <main className="flex-1 overflow-x-hidden">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
