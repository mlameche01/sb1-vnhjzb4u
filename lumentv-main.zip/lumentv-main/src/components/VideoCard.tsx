import { Link, useNavigate } from "react-router-dom";
import { Play } from "lucide-react";
import {
  Claim,
  formatDuration,
  formatRelativeTime,
  thumbnail,
  videoSlug,
  channelSlugFromUrl,
} from "@/lib/lbry";

export default function VideoCard({ claim }: { claim: Claim }) {
  const navigate = useNavigate();
  const thumb = thumbnail(claim.thumbnail_url);
  const duration = formatDuration(claim.duration);
  const time = formatRelativeTime(claim.timestamp);

  return (
    <Link
      to={`/video/${encodeURIComponent(videoSlug(claim))}`}
      className="group relative flex flex-col overflow-hidden rounded-xl border border-border/60 bg-gradient-card transition-smooth hover:border-primary/50 hover:shadow-glow-sm"
    >
      <div className="relative aspect-video overflow-hidden bg-muted">
        {thumb ? (
          <img
            src={thumb}
            alt={claim.title}
            loading="lazy"
            className="h-full w-full object-cover transition-smooth group-hover:scale-105"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = "none";
            }}
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center grid-bg">
            <Play className="h-10 w-10 text-primary/40" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 transition-smooth group-hover:opacity-100" />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-smooth group-hover:opacity-100">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary shadow-glow">
            <Play className="ml-0.5 h-5 w-5 fill-primary-foreground text-primary-foreground" />
          </div>
        </div>
        {duration && (
          <span className="absolute bottom-2 right-2 rounded-md bg-background/90 px-1.5 py-0.5 font-mono text-[11px] font-medium text-foreground backdrop-blur-sm">
            {duration}
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-1 p-3">
        <h3 className="line-clamp-2 font-display text-sm font-semibold leading-snug text-foreground transition-smooth group-hover:text-primary">
          {claim.title}
        </h3>
        <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
          {claim.channel_name &&
            (() => {
              const channelSlug = channelSlugFromUrl(claim.channel_url);
              return channelSlug ? (
                <span
                  role="link"
                  tabIndex={0}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    navigate(`/channel/${channelSlug}`);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      e.stopPropagation();
                      navigate(`/channel/${channelSlug}`);
                    }
                  }}
                  className="cursor-pointer truncate font-medium text-foreground/80 hover:text-primary"
                >
                  @{claim.channel_name}
                </span>
              ) : (
                <span className="truncate font-medium text-foreground/80">
                  @{claim.channel_name}
                </span>
              );
            })()}
          {time && (
            <>
              <span className="text-muted-foreground/50">•</span>
              <span className="font-mono text-[11px]">{time}</span>
            </>
          )}
        </div>
      </div>
    </Link>
  );
}

export function VideoCardSkeleton() {
  return (
    <div className="flex flex-col overflow-hidden rounded-xl border border-border/60 bg-gradient-card">
      <div className="aspect-video animate-pulse bg-muted" />
      <div className="space-y-2 p-3">
        <div className="h-4 w-3/4 animate-pulse rounded bg-muted" />
        <div className="h-3 w-1/2 animate-pulse rounded bg-muted" />
      </div>
    </div>
  );
}
