// LBRY / Odysee public API client
// Docs: https://lbry.tech/api/sdk

const API_URL = "https://api.na-backend.odysee.com/api/v1/proxy";
const LIGHTHOUSE_URL = "https://lighthouse.odysee.tv/search";
const THUMBNAIL_CDN =
  "https://thumbnails.odycdn.com/optimize/s:390:0/quality:85/plain/";
const PLAYER_CDN = "https://player.odycdn.com/api/v3/streams/free";

// ─── Types ────────────────────────────────────────────────────────────────────

export type Claim = {
  claim_id: string;
  name: string;
  canonical_url: string;
  permanent_url: string;
  short_url: string;
  title?: string;
  thumbnail_url?: string;
  release_time?: string;
  timestamp?: number;
  duration?: number;
  channel_name?: string;
  channel_url?: string;
  channel_thumbnail?: string;
  description?: string;
  view_count?: number;
  source_url?: string;
  embed_url?: string;
};

type RawClaim = {
  claim_id: string;
  name: string;
  canonical_url: string;
  permanent_url: string;
  short_url: string;
  timestamp?: number;
  signing_channel?: {
    name?: string;
    canonical_url?: string;
    value?: { thumbnail?: { url?: string } };
  };
  value?: {
    title?: string;
    description?: string;
    thumbnail?: { url?: string };
    release_time?: string;
    video?: { duration?: number };
    audio?: { duration?: number };
    source?: { media_type?: string; sd_hash?: string };
  };
};

type ClaimSearchResult = { items: RawClaim[]; total_items?: number };

export type SearchMediaType = "video" | "audio" | "document" | "all";

// ─── Normalize ────────────────────────────────────────────────────────────────

function normalize(c: RawClaim): Claim {
  const sdHash = c.value?.source?.sd_hash;

  const source_url = sdHash
    ? `${PLAYER_CDN}/${encodeURIComponent(c.name)}/${c.claim_id}/${sdHash.slice(0, 6)}.mp4`
    : undefined;

  const embed_url = `https://odysee.com/$/embed/${encodeURIComponent(c.name)}/${c.claim_id}`;

  return {
    claim_id: c.claim_id,
    name: c.name,
    canonical_url: c.canonical_url,
    permanent_url: c.permanent_url,
    short_url: c.short_url,
    title: c.value?.title || c.name,
    thumbnail_url: c.value?.thumbnail?.url,
    release_time: c.value?.release_time,
    timestamp: c.timestamp,
    duration: c.value?.video?.duration || c.value?.audio?.duration,
    channel_name: c.signing_channel?.name,
    channel_url: c.signing_channel?.canonical_url,
    channel_thumbnail: c.signing_channel?.value?.thumbnail?.url,
    description: c.value?.description,
    source_url,
    embed_url,
  };
}

// ─── RPC core ─────────────────────────────────────────────────────────────────

async function rpc<T>(
  method: string,
  params: Record<string, unknown>
): Promise<T> {
  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", method, params, id: Date.now() }),
  });

  if (!res.ok) throw new Error(`LBRY API error: ${res.status}`);

  const data = await res.json();

  if (data.error) {
    const msg =
      typeof data.error === "object"
        ? data.error.message || JSON.stringify(data.error)
        : String(data.error);
    throw new Error(`LBRY RPC error: ${msg}`);
  }

  return data.result as T;
}

// ─── getTrending ──────────────────────────────────────────────────────────────

export async function getTrending(
  page = 1,
  pageSize = 24
): Promise<Claim[]> {
  const result = await rpc<ClaimSearchResult>("claim_search", {
    page,
    page_size: pageSize,
    no_totals: true,
    claim_type: ["stream"],
    stream_types: ["video"],
    order_by: ["trending_group", "trending_mixed"],
    has_source: true,
    not_channel_ids: [],
    any_languages: ["ar"],
  });
  return (result.items || []).map(normalize);
}

// ─── getChannelVideos ─────────────────────────────────────────────────────────

export async function getChannelVideos(
  channelId: string,
  page = 1,
  pageSize = 30
): Promise<Claim[]> {
  const result = await rpc<ClaimSearchResult>("claim_search", {
    channel_ids: [channelId],
    page,
    page_size: pageSize,
    no_totals: true,
    claim_type: ["stream"],
    stream_types: ["video"],
    order_by: ["release_time"],
    has_source: true,
  });
  return (result.items || []).map(normalize);
}

// ─── resolveChannel ───────────────────────────────────────────────────────────

export async function resolveChannel(url: string): Promise<Claim | null> {
  const result = await rpc<Record<string, RawClaim | { error?: unknown }>>(
    "resolve",
    { urls: [url], include_purchase_receipt: false }
  );
  const raw = result[url];
  if (!raw || (raw as { error?: unknown }).error) return null;
  return normalize(raw as RawClaim);
}

// ─── searchVideos ─────────────────────────────────────────────────────────────
//
// Stratégie en 2 étapes :
//   1. Lighthouse avec paramètres minimaux uniquement (s, size, from).
//      Aucun paramètre nsfw / claimType / mediaType / streamType car ils
//      varient selon les versions de l'API et déclenchent des erreurs 400.
//   2. Fallback sur claim_search avec any_tags si Lighthouse est indisponible.
//      On n'utilise PAS le paramètre `text` dans claim_search (→ -32603).

export async function searchVideos(
  query: string,
  page = 1,
  pageSize = 24,
  mediaType: SearchMediaType = "video"
): Promise<Claim[]> {
  if (!query.trim()) return [];

  // ── Étape 1 : Lighthouse ──────────────────────────────────────────
  try {
    const lighthouseParams = new URLSearchParams({
      s: query.trim(),
      size: String(pageSize),
      from: String((page - 1) * pageSize),
      // Forcer les résultats en arabe
      language: "ar",
      mediaType: mediaType === "all" ? "video" : mediaType,
      claimType: "stream",
    });

    const lighthouseRes = await fetch(
      `${LIGHTHOUSE_URL}?${lighthouseParams.toString()}`
    );

    if (lighthouseRes.ok) {
      const lighthouseItems = (await lighthouseRes.json()) as {
        claimId?: string;
      }[];

      const ids = lighthouseItems
        .map((i) => i.claimId)
        .filter(Boolean) as string[];

      if (!ids.length) return [];

      const resolved = await rpc<ClaimSearchResult>("claim_search", {
        claim_ids: ids,
        page: 1,
        page_size: pageSize,
        no_totals: true,
      });

      const map = new Map(
        (resolved.items || []).map((c) => [c.claim_id, normalize(c)])
      );

      // Préserve l'ordre de pertinence renvoyé par Lighthouse
      return ids.map((id) => map.get(id)).filter(Boolean) as Claim[];
    }
  } catch {
    // Lighthouse indisponible → fallback
  }

  // ── Étape 2 : Fallback claim_search avec any_tags ─────────────────
  const streamTypes =
    mediaType === "all" ? ["video", "audio"] : [mediaType];

  // Forcer la langue arabe dans le fallback
  const arabicTags = ["arabic", "arab", "عربي", "عربية", "arabic-content"];
  const queryTags = query.trim().toLowerCase().split(/\s+/).filter(Boolean);

  const fallbackResult = await rpc<ClaimSearchResult>("claim_search", {
    any_tags: [...queryTags, ...arabicTags],
    page,
    page_size: pageSize,
    no_totals: true,
    claim_type: ["stream"],
    stream_types: streamTypes,
    order_by: ["release_time"],
    has_source: true,
    any_languages: ["ar"],
  });

  return (fallbackResult.items || []).map(normalize);
}

// ─── resolveClaim ─────────────────────────────────────────────────────────────

export async function resolveClaim(url: string): Promise<Claim | null> {
  const result = await rpc<Record<string, RawClaim | { error?: unknown }>>(
    "resolve",
    { urls: [url], include_purchase_receipt: false }
  );
  const raw = result[url];
  if (!raw || (raw as { error?: unknown }).error) return null;
  return normalize(raw as RawClaim);
}

// ─── getStreamUrl ─────────────────────────────────────────────────────────────
// Pas d'appel RPC "get" (bloqué par CORS).
// 1. Essaie le CDN direct (mp4), 2. Fallback embed Odysee.

export async function getStreamUrl(
  _uri: string,
  claim?: Claim
): Promise<string> {
  if (claim?.source_url) {
    try {
      const res = await fetch(claim.source_url, { method: "HEAD" });
      if (res.ok) return claim.source_url;
    } catch {
      // continue vers fallback
    }
  }

  if (claim?.embed_url) return claim.embed_url;

  throw new Error("Aucune URL de stream disponible pour cette vidéo.");
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function formatDuration(seconds?: number): string {
  if (!seconds || seconds <= 0) return "";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h)
    return `${h}:${m.toString().padStart(2, "0")}:${s
      .toString()
      .padStart(2, "0")}`;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function formatRelativeTime(ts?: number | string): string {
  if (!ts) return "";
  const date = typeof ts === "number" ? new Date(ts * 1000) : new Date(ts);
  const diff = (Date.now() - date.getTime()) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 2592000) return `${Math.floor(diff / 86400)}d ago`;
  if (diff < 31536000) return `${Math.floor(diff / 2592000)}mo ago`;
  return `${Math.floor(diff / 31536000)}y ago`;
}

export function thumbnail(url?: string): string {
  if (!url) return "";
  return `${THUMBNAIL_CDN}${encodeURIComponent(url)}`;
}

export function videoSlug(claim: Claim): string {
  return `${claim.name}:${claim.claim_id}`;
}

export function parseSlug(
  slug: string
): { name: string; claimId: string } | null {
  const idx = slug.lastIndexOf(":");
  if (idx === -1) return null;
  return { name: slug.slice(0, idx), claimId: slug.slice(idx + 1) };
}

export function channelSlugFromUrl(channelUrl?: string): string | null {
  if (!channelUrl) return null;
  const stripped = channelUrl.replace(/^lbry:\/\//, "");
  const channelPart = stripped.split("/")[0];
  const hashIdx = channelPart.indexOf("#");
  if (hashIdx === -1) return encodeURIComponent(channelPart);
  const name = channelPart.slice(0, hashIdx);
  const id = channelPart.slice(hashIdx + 1);
  return `${encodeURIComponent(name)}:${id}`;
}

export function parseChannelSlug(
  slug: string
): { name: string; id: string } | null {
  const decoded = decodeURIComponent(slug);
  const idx = decoded.lastIndexOf(":");
  if (idx === -1) return null;
  return { name: decoded.slice(0, idx), id: decoded.slice(idx + 1) };
}
