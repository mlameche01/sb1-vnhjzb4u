// Helpers EVM minimaux (sans dépendre de ethers/web3)
// Encode/décode les appels ERC-20 standards via window.ethereum.

// TXDC est la monnaie native du réseau XDC Apothem (équivalent ETH).
// Elle n'est PAS un ERC-20 — son solde est lu via eth_getBalance, pas balanceOf.
// L'adresse 0xCCC5…64Da est juste le contrat système exposant des métadonnées,
// pas un token transférable via la norme ERC-20.
export const NATIVE_TOKEN = {
  symbol: "TXDC",
  decimals: 18,
} as const;

// XSwap V2 on XDC Apothem testnet — https://docs.xspswap.finance
export const XSWAP_APOTHEM = {
  router: "0x3F11A24EB45d3c3737365b97A996949dA6c2EdDf",
  factory: "0xCae66ac135d6489BDF5619Ae8F8f1e724765eb8f",
  wxdc: "0x2a5c77b016Df1b3b0AE4E79a68F8adF64Ee741ba",
} as const;

export const ERC20_TOKENS = {
  DZD: {
    address: "0x5918e70C4eD6269d73a074bb9BF0b91dcb29Bb84",
    symbol: "DZD",
    decimals: 18,
  },
} as const;

export type TokenKey = keyof typeof ERC20_TOKENS;

// Function selectors (keccak256 prefixes)
const SEL_BALANCE_OF = "0x70a08231";
const SEL_DECIMALS = "0x313ce567";
const SEL_SYMBOL = "0x95d89b41";
const SEL_APPROVE = "0x095ea7b3";
const SEL_ALLOWANCE = "0xdd62ed3e";

function getEth(): any {
  return (window as any).ethereum ?? null;
}

function pad32(hex: string): string {
  return hex.replace(/^0x/, "").padStart(64, "0");
}

function addrToTopic(addr: string): string {
  return pad32(addr.toLowerCase());
}

function bigIntToHex(n: bigint): string {
  return "0x" + n.toString(16);
}

export function toUnits(amount: string, decimals: number): bigint {
  const [whole, frac = ""] = amount.split(".");
  const fracPadded = (frac + "0".repeat(decimals)).slice(0, decimals);
  return BigInt(whole || "0") * 10n ** BigInt(decimals) + BigInt(fracPadded || "0");
}

export function fromUnits(value: bigint, decimals: number, displayDecimals = 4): string {
  const base = 10n ** BigInt(decimals);
  const whole = value / base;
  const frac = value % base;
  const fracStr = frac.toString().padStart(decimals, "0").slice(0, displayDecimals);
  return `${whole}.${fracStr}`.replace(/\.?0+$/, "") || "0";
}

async function ethCall(to: string, data: string): Promise<string> {
  const eth = getEth();
  if (!eth) throw new Error("No EVM wallet detected");
  return eth.request({
    method: "eth_call",
    params: [{ to, data }, "latest"],
  });
}

export async function getErc20Balance(token: string, account: string): Promise<bigint> {
  const data = SEL_BALANCE_OF + addrToTopic(account);
  const raw = await ethCall(token, data);
  return BigInt(raw === "0x" ? "0x0" : raw);
}

export async function getErc20Decimals(token: string): Promise<number> {
  try {
    const raw = await ethCall(token, SEL_DECIMALS);
    return Number(BigInt(raw === "0x" ? "0x12" : raw));
  } catch {
    return 18;
  }
}

export async function getErc20Allowance(
  token: string,
  owner: string,
  spender: string,
): Promise<bigint> {
  const data = SEL_ALLOWANCE + addrToTopic(owner) + addrToTopic(spender);
  const raw = await ethCall(token, data);
  return BigInt(raw === "0x" ? "0x0" : raw);
}

export async function approveErc20(
  token: string,
  spender: string,
  amount: bigint,
  from: string,
): Promise<string> {
  const eth = getEth();
  if (!eth) throw new Error("No EVM wallet detected");
  const data = SEL_APPROVE + addrToTopic(spender) + pad32(amount.toString(16));
  return eth.request({
    method: "eth_sendTransaction",
    params: [{ from, to: token, data }],
  });
}

// ERC-20 transfer(address,uint256)
const SEL_TRANSFER = "0xa9059cbb";

export async function transferErc20(
  token: string,
  to: string,
  amount: bigint,
  from: string,
): Promise<string> {
  const eth = getEth();
  if (!eth) throw new Error("No EVM wallet detected");
  const data = SEL_TRANSFER + addrToTopic(to) + pad32(amount.toString(16));
  return eth.request({
    method: "eth_sendTransaction",
    params: [{ from, to: token, data }],
  });
}

// Uniswap V2 Router: swapExactTokensForTokens
// 0x38ed1739: swapExactTokensForTokens(uint256,uint256,address[],address,uint256)
const SEL_SWAP_EXACT_TOKENS = "0x38ed1739";

export async function swapExactTokensForTokens(opts: {
  router: string;
  amountIn: bigint;
  amountOutMin: bigint;
  path: string[];
  to: string;
  deadline: bigint;
  from: string;
}): Promise<string> {
  const eth = getEth();
  if (!eth) throw new Error("No EVM wallet detected");

  // Encode dynamic address[] manually (offset-based)
  // Static head (5 * 32 bytes):
  //   amountIn, amountOutMin, offsetToPath, to, deadline
  // Then dynamic tail: length + addresses
  const headFields = 5;
  const offsetToPath = headFields * 32; // bytes
  const head =
    pad32(opts.amountIn.toString(16)) +
    pad32(opts.amountOutMin.toString(16)) +
    pad32(offsetToPath.toString(16)) +
    addrToTopic(opts.to) +
    pad32(opts.deadline.toString(16));
  const tail =
    pad32(BigInt(opts.path.length).toString(16)) + opts.path.map(addrToTopic).join("");
  const data = SEL_SWAP_EXACT_TOKENS + head + tail;

  return eth.request({
    method: "eth_sendTransaction",
    params: [{ from: opts.from, to: opts.router, data }],
  });
}

// Uniswap V2 Router: getAmountsOut(uint256,address[]) -> uint256[]
const SEL_GET_AMOUNTS_OUT = "0xd06ca61f";

export async function getAmountsOut(
  router: string,
  amountIn: bigint,
  path: string[],
): Promise<bigint[]> {
  const offsetToPath = 2 * 32;
  const head = pad32(amountIn.toString(16)) + pad32(offsetToPath.toString(16));
  const tail =
    pad32(BigInt(path.length).toString(16)) + path.map(addrToTopic).join("");
  const data = SEL_GET_AMOUNTS_OUT + head + tail;
  const raw: string = await ethCall(router, data);
  // Decode uint256[]: first 32 bytes = offset, next 32 = length, then values
  const hex = raw.replace(/^0x/, "");
  const len = Number(BigInt("0x" + hex.slice(64, 128)));
  const out: bigint[] = [];
  for (let i = 0; i < len; i++) {
    const start = 128 + i * 64;
    out.push(BigInt("0x" + hex.slice(start, start + 64)));
  }
  return out;
}

// Uniswap V2 Router: swapExactETHForTokens(uint256,address[],address,uint256)
const SEL_SWAP_EXACT_ETH_FOR_TOKENS = "0x7ff36ab5";
// Uniswap V2 Router: swapExactTokensForETH(uint256,uint256,address[],address,uint256)
const SEL_SWAP_EXACT_TOKENS_FOR_ETH = "0x18cbafe5";

export async function swapExactETHForTokens(opts: {
  router: string;
  amountInWei: bigint;
  amountOutMin: bigint;
  path: string[];
  to: string;
  deadline: bigint;
  from: string;
}): Promise<string> {
  const eth = getEth();
  if (!eth) throw new Error("No EVM wallet detected");
  // head: amountOutMin, offsetToPath, to, deadline (4 fields)
  const offsetToPath = 4 * 32;
  const head =
    pad32(opts.amountOutMin.toString(16)) +
    pad32(offsetToPath.toString(16)) +
    addrToTopic(opts.to) +
    pad32(opts.deadline.toString(16));
  const tail =
    pad32(BigInt(opts.path.length).toString(16)) + opts.path.map(addrToTopic).join("");
  const data = SEL_SWAP_EXACT_ETH_FOR_TOKENS + head + tail;
  return eth.request({
    method: "eth_sendTransaction",
    params: [
      {
        from: opts.from,
        to: opts.router,
        data,
        value: bigIntToHex(opts.amountInWei),
      },
    ],
  });
}

export async function swapExactTokensForETH(opts: {
  router: string;
  amountIn: bigint;
  amountOutMin: bigint;
  path: string[];
  to: string;
  deadline: bigint;
  from: string;
}): Promise<string> {
  const eth = getEth();
  if (!eth) throw new Error("No EVM wallet detected");
  const offsetToPath = 5 * 32;
  const head =
    pad32(opts.amountIn.toString(16)) +
    pad32(opts.amountOutMin.toString(16)) +
    pad32(offsetToPath.toString(16)) +
    addrToTopic(opts.to) +
    pad32(opts.deadline.toString(16));
  const tail =
    pad32(BigInt(opts.path.length).toString(16)) + opts.path.map(addrToTopic).join("");
  const data = SEL_SWAP_EXACT_TOKENS_FOR_ETH + head + tail;
  return eth.request({
    method: "eth_sendTransaction",
    params: [{ from: opts.from, to: opts.router, data }],
  });
}

