import { Link } from "react-router-dom";
import { Heart, User, Trash2 } from "lucide-react";
import { useFavorites } from "@/hooks/useFavorites";
import { thumbnail } from "@/lib/lbry";
import { Button } from "@/components/ui/button";

export default function FavoritesPage() {
  const { favorites, remove } = useFavorites();

  return (
    <div className="mx-auto max-w-[1600px] px-4 py-6 md:px-8 md:py-8">
      <header className="mb-8">
        <div className="mb-1 flex items-center gap-2">
          <Heart className="h-4 w-4 text-primary text-glow" />
          <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
            Your collection
          </span>
        </div>
        <h1 className="font-display text-2xl font-bold tracking-tight md:text-3xl">
          Favorite channels
        </h1>
        <p className="mt-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
          {favorites.length} channel{favorites.length === 1 ? "" : "s"} saved locally
        </p>
      </header>

      {favorites.length === 0 ? (
        <div className="rounded-xl border border-border/60 bg-card/40 p-12 text-center">
          <Heart className="mx-auto mb-3 h-8 w-8 text-muted-foreground/50" />
          <p className="text-muted-foreground">
            No favorite channels yet. Open a channel and tap the heart to save it here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {favorites.map((fav) => {
            const thumb = fav.thumbnail ? thumbnail(fav.thumbnail) : "";
            return (
              <div
                key={fav.slug}
                className="group flex items-center gap-3 rounded-xl border border-border/60 bg-card/40 p-3 transition-smooth hover:border-primary/50 hover:shadow-glow-sm"
              >
                <Link to={`/channel/${fav.slug}`} className="flex flex-1 items-center gap-3">
                  {thumb ? (
                    <img
                      src={thumb}
                      alt={fav.name}
                      className="h-12 w-12 shrink-0 rounded-full border border-primary/30 object-cover"
                    />
                  ) : (
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-primary">
                      <User className="h-5 w-5 text-primary-foreground" />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-display font-semibold text-foreground transition-smooth group-hover:text-primary">
                      {fav.title || fav.name}
                    </p>
                    <p className="truncate font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                      {fav.name}
                    </p>
                  </div>
                </Link>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => remove(fav.slug)}
                  aria-label="Remove from favorites"
                  className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
