import { useEffect, useState, FormEvent } from "react";
import { useSearchParams } from "react-router-dom";
import { Search, AlertCircle, Video, Music, FileText, LayoutGrid } from "lucide-react";
import { searchVideos, Claim, SearchMediaType } from "@/lib/lbry";
import VideoCard, { VideoCardSkeleton } from "@/components/VideoCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const FILTERS: { value: SearchMediaType; label: string; Icon: typeof Video }[] = [
  { value: "all", label: "All", Icon: LayoutGrid },
  { value: "video", label: "Video", Icon: Video },
  { value: "audio", label: "Audio", Icon: Music },
  { value: "document", label: "Document", Icon: FileText },
];

export default function SearchPage() {
  const [params, setParams] = useSearchParams();
  const q = params.get("q") || "";
  const typeParam = (params.get("type") as SearchMediaType) || "video";
  const [input, setInput] = useState(q);
  const [results, setResults] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => setInput(q), [q]);

  useEffect(() => {
    if (!q) {
      setResults([]);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);
    searchVideos(q, 1, 30, typeParam)
      .then((items) => {
        if (!cancelled) setResults(items);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message || "Search failed");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [q, typeParam]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;
    setParams({ q: input.trim(), type: typeParam });
  }

  function setType(t: SearchMediaType) {
    const next: Record<string, string> = { type: t };
    if (q) next.q = q;
    setParams(next);
  }

  return (
    <div className="relative min-h-full">
      <div className="mx-auto max-w-[1600px] px-4 py-6 md:px-8 md:py-10">
        <header className="mb-8">
          <div className="mb-2 flex items-center gap-2">
            <Search className="h-5 w-5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-widest text-primary">
              Network search
            </span>
          </div>
          <h1 className="mb-4 font-display text-3xl font-bold tracking-tight md:text-4xl">
            Find anything on LBRY
          </h1>
          <form onSubmit={onSubmit} className="flex max-w-2xl gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Try ‘bitcoin’, ‘music’, ‘gaming’..."
              className="h-11 border-border/60 bg-card/60 font-mono focus-visible:border-primary focus-visible:ring-primary/20"
            />
            <Button
              type="submit"
              className="h-11 bg-gradient-primary px-6 font-medium text-primary-foreground shadow-glow-sm hover:shadow-glow"
            >
              Search
            </Button>
          </form>

          <div className="mt-4 flex flex-wrap gap-2">
            {FILTERS.map(({ value, label, Icon }) => {
              const active = typeParam === value;
              return (
                <button
                  key={value}
                  type="button"
                  onClick={() => setType(value)}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 font-mono text-[11px] uppercase tracking-widest transition-smooth",
                    active
                      ? "border-primary/60 bg-primary/10 text-primary shadow-glow-sm"
                      : "border-border/60 bg-card/60 text-muted-foreground hover:border-primary/40 hover:text-primary",
                  )}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {label}
                </button>
              );
            })}
          </div>
        </header>

        {error && (
          <div className="mb-6 flex items-center gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
            <AlertCircle className="h-4 w-4" />
            <span>{error}</span>
          </div>
        )}

        {q && (
          <p className="mb-4 font-mono text-xs uppercase tracking-widest text-muted-foreground">
            {loading ? "Searching" : `${results.length} results`} for{" "}
            <span className="text-primary">"{q}"</span>
            <span className="text-muted-foreground/60"> · {typeParam}</span>
          </p>
        )}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
          {loading
            ? Array.from({ length: 8 }).map((_, i) => <VideoCardSkeleton key={i} />)
            : results.map((claim) => <VideoCard key={claim.claim_id} claim={claim} />)}
        </div>

        {!loading && q && results.length === 0 && !error && (
          <div className="rounded-xl border border-border/60 bg-card/40 p-12 text-center">
            <p className="text-muted-foreground">No results for "{q}".</p>
          </div>
        )}

        {!q && !loading && (
          <div className="rounded-xl border border-dashed border-border/60 bg-card/30 p-12 text-center">
            <Search className="mx-auto mb-3 h-8 w-8 text-muted-foreground/50" />
            <p className="text-muted-foreground">
              Enter a query to search the decentralized network.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
