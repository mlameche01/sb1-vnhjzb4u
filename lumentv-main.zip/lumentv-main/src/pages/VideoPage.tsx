import { useEffect, useState, useRef, useCallback } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import ReactPlayer from "react-player";
import { ArrowLeft, AlertCircle, Calendar, User, Hash, Play, SkipForward, X } from "lucide-react";
import SponsorButton from "@/components/SponsorButton";
import {
  resolveClaim,
  getStreamUrl,
  getChannelVideos,
  parseSlug,
  Claim,
  formatRelativeTime,
  thumbnail,
  channelSlugFromUrl,
  videoSlug,
} from "@/lib/lbry";
import { VideoCardSkeleton } from "@/components/VideoCard";

const AUTOPLAY_DELAY = 5;

/** Extrait le claim_id de la chaîne depuis channel_url */
function extractChannelId(channelUrl?: string): string | null {
  if (!channelUrl) return null;
  const match = channelUrl.replace(/^lbry:\/\//, "").match(/#([a-f0-9]+)/i);
  return match ? match[1] : null;
}

export default function VideoPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const [claim, setClaim] = useState<Claim | null>(null);
  const [streamUrl, setStreamUrl] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isEmbed, setIsEmbed] = useState(false);

  const [nextVideo, setNextVideo] = useState<Claim | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [autoplaying, setAutoplaying] = useState(false);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // Référence stable à nextVideo pour éviter les closures périmées
  const nextVideoRef = useRef<Claim | null>(null);
  useEffect(() => { nextVideoRef.current = nextVideo; }, [nextVideo]);

  const cancelAutoplay = useCallback(() => {
    if (countdownRef.current) clearInterval(countdownRef.current);
    setCountdown(null);
    setAutoplaying(false);
  }, []);

  const goToNext = useCallback((next: Claim) => {
    if (countdownRef.current) clearInterval(countdownRef.current);
    setCountdown(null);
    setAutoplaying(false);
    navigate(`/video/${encodeURIComponent(videoSlug(next))}`);
  }, [navigate]);

  const startCountdown = useCallback((next: Claim) => {
    if (countdownRef.current) clearInterval(countdownRef.current);
    setAutoplaying(true);
    setCountdown(AUTOPLAY_DELAY);
    let remaining = AUTOPLAY_DELAY;
    countdownRef.current = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0) {
        clearInterval(countdownRef.current!);
        setCountdown(null);
        setAutoplaying(false);
        // Utilise la ref pour avoir la valeur fraîche
        const n = nextVideoRef.current;
        if (n) navigate(`/video/${encodeURIComponent(videoSlug(n))}`);
      } else {
        setCountdown(remaining);
      }
    }, 1000);
  }, [navigate]);

  // onEnded déclenché par ReactPlayer quand la vidéo mp4 se termine
  const handleVideoEnded = useCallback(() => {
    const next = nextVideoRef.current;
    if (next) startCountdown(next);
  }, [startCountdown]);

  useEffect(() => () => {
    if (countdownRef.current) clearInterval(countdownRef.current);
  }, []);

  // ── Charge la vidéo + vidéos de la chaîne ────────────────────────
  useEffect(() => {
    if (!slug) return;
    const decoded = decodeURIComponent(slug);
    const parsed = parseSlug(decoded);
    if (!parsed) {
      setError("Invalid video URL");
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError(null);
    setClaim(null);
    setStreamUrl("");
    setIsEmbed(false);
    setNextVideo(null);
    nextVideoRef.current = null;
    cancelAutoplay();

    resolveClaim(`lbry://${parsed.name}#${parsed.claimId}`)
      .then(async (c) => {
        if (cancelled) return;
        if (!c) { setError("Video not found on the network"); return; }
        setClaim(c);

        // Stream — source_url en priorité (mp4 direct, onEnded fonctionne)
        try {
          const stream = await getStreamUrl(c.canonical_url, c);
          if (!cancelled) {
            setStreamUrl(stream);
            setIsEmbed(stream.includes("odysee.com/$/embed"));
          }
        } catch (e) {
          if (!cancelled) setError((e as Error).message || "Stream unavailable");
        }

        // Vidéos de la chaîne
        const channelId = extractChannelId(c.channel_url);
        if (channelId) {
          try {
            const videos = await getChannelVideos(channelId, 1, 20);
            if (cancelled) return;
            const idx = videos.findIndex((v) => v.claim_id === c.claim_id);
            const next =
              idx >= 0 && idx < videos.length - 1
                ? videos[idx + 1]
                : idx === -1 && videos.length > 0
                ? videos[0]
                : null;
            setNextVideo(next);
            nextVideoRef.current = next;
          } catch { /* pas bloquant */ }
        }
      })
      .catch((err) => { if (!cancelled) setError(err.message || "Failed to load video"); })
      .finally(() => { if (!cancelled) setLoading(false); });

    return () => { cancelled = true; };
  }, [slug]);

  const channelThumb = claim?.channel_thumbnail ? thumbnail(claim.channel_thumbnail) : "";
  const nextThumb = nextVideo?.thumbnail_url ? thumbnail(nextVideo.thumbnail_url) : "";

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 md:px-8 md:py-8">
      <Link
        to="/"
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-smooth hover:text-primary"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to trending
      </Link>

      {error && (
        <div className="flex items-center gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          <AlertCircle className="h-4 w-4" />
          <span>{error}</span>
        </div>
      )}

      {loading && (
        <div className="space-y-4">
          <div className="aspect-video w-full animate-pulse rounded-xl bg-muted" />
          <VideoCardSkeleton />
        </div>
      )}

      {claim && (
        <article>
          {/* ── Lecteur ── */}
          <div className="relative overflow-hidden rounded-xl border border-border/60 bg-black shadow-card neon-border">
            <div className="aspect-video w-full">
              {streamUrl ? (
                isEmbed ? (
                  <iframe
                    src={streamUrl}
                    className="h-full w-full"
                    allowFullScreen
                    allow="autoplay; encrypted-media"
                  />
                ) : (
                  <ReactPlayer
                    url={streamUrl}
                    controls
                    playing
                    width="100%"
                    height="100%"
                    onEnded={handleVideoEnded}
                    onError={() => {
                      // Si le mp4 échoue à la lecture, bascule sur l'embed
                      if (claim?.embed_url) {
                        setStreamUrl(claim.embed_url);
                        setIsEmbed(true);
                      }
                    }}
                    config={{ file: { attributes: { crossOrigin: "anonymous" } } }}
                  />
                )
              ) : (
                <div className="flex h-full w-full items-center justify-center text-xs font-mono uppercase tracking-widest text-muted-foreground">
                  Resolving stream…
                </div>
              )}
            </div>

            {/* ── Overlay autoplay ── */}
            {autoplaying && nextVideo && countdown !== null && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-sm">
                <div className="w-full max-w-sm rounded-2xl border border-border/60 bg-card/95 p-6 shadow-xl">
                  <div className="mb-4 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm font-medium text-primary">
                      <SkipForward className="h-4 w-4" />
                      Lecture automatique dans {countdown}s
                    </div>
                    <button
                      onClick={cancelAutoplay}
                      className="rounded-full p-1 text-muted-foreground transition hover:text-foreground"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>

                  {nextThumb && (
                    <div className="mb-4 overflow-hidden rounded-lg border border-border/60">
                      <img
                        src={nextThumb}
                        alt={nextVideo.title}
                        className="aspect-video w-full object-cover"
                      />
                    </div>
                  )}

                  <p className="mb-1 text-xs text-muted-foreground">Vidéo suivante</p>
                  <p className="mb-4 line-clamp-2 text-sm font-semibold leading-snug text-foreground">
                    {nextVideo.title || nextVideo.name}
                  </p>

                  <div className="mb-4 h-1 w-full overflow-hidden rounded-full bg-border/60">
                    <div
                      className="h-full bg-primary transition-all duration-1000"
                      style={{ width: `${((AUTOPLAY_DELAY - countdown) / AUTOPLAY_DELAY) * 100}%` }}
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => goToNext(nextVideo)}
                      className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition hover:opacity-90"
                    >
                      <Play className="h-4 w-4" />
                      Lire maintenant
                    </button>
                    <button
                      onClick={cancelAutoplay}
                      className="flex-1 rounded-lg border border-border/60 bg-card/60 px-4 py-2 text-sm text-muted-foreground transition hover:text-foreground"
                    >
                      Annuler
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* ── Infos ── */}
          <div className="mt-5">
            <h1 className="font-display text-2xl font-bold leading-tight tracking-tight md:text-3xl">
              {claim.title}
            </h1>

            <div className="mt-4 flex flex-wrap items-center gap-4 border-b border-border/60 pb-4">
              {(() => {
                const channelSlug = channelSlugFromUrl(claim.channel_url);
                const ChannelInner = (
                  <>
                    {channelThumb ? (
                      <img
                        src={channelThumb}
                        alt={claim.channel_name}
                        className="h-10 w-10 rounded-full border border-primary/30 object-cover"
                      />
                    ) : (
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-primary">
                        <User className="h-5 w-5 text-primary-foreground" />
                      </div>
                    )}
                    <div>
                      <p className="font-display font-semibold text-foreground transition-smooth group-hover:text-primary">
                        @{claim.channel_name || "anonymous"}
                      </p>
                      <p className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                        LBRY creator
                      </p>
                    </div>
                  </>
                );
                return channelSlug ? (
                  <Link to={`/channel/${channelSlug}`} className="group flex items-center gap-3">
                    {ChannelInner}
                  </Link>
                ) : (
                  <div className="flex items-center gap-3">{ChannelInner}</div>
                );
              })()}

              <div className="ml-auto flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                {claim.timestamp && (
                  <span className="flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5" />
                    {formatRelativeTime(claim.timestamp)}
                  </span>
                )}
                <span className="flex items-center gap-1.5 font-mono">
                  <Hash className="h-3.5 w-3.5" />
                  {claim.claim_id.slice(0, 8)}
                </span>

                {/* ── Bouton de sponsoring ── */}
                <SponsorButton
                  creatorName={claim.channel_name?.replace(/^@/, "")}
                />
              </div>
            </div>

            {claim.description && (
              <div className="mt-4 rounded-xl border border-border/60 bg-card/60 p-4">
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-foreground/80">
                  {claim.description}
                </p>
              </div>
            )}

            {/* ── Vidéo suivante (toujours visible, sauf pendant l'overlay) ── */}
            {nextVideo && !autoplaying && (
              <div className="mt-4 rounded-xl border border-border/60 bg-card/60 p-4">
                <p className="mb-3 flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground">
                  <SkipForward className="h-3.5 w-3.5" />
                  {isEmbed
                    ? "Vidéo suivante de la chaîne"
                    : "Lecture automatique après cette vidéo"}
                </p>
                <button
                  onClick={() => goToNext(nextVideo)}
                  className="group flex w-full items-center gap-3 rounded-lg border border-border/60 bg-background/40 p-3 text-left transition hover:border-primary/40 hover:bg-primary/5"
                >
                  <div className="relative h-16 w-28 shrink-0 overflow-hidden rounded-md border border-border/60">
                    {nextThumb ? (
                      <img src={nextThumb} alt={nextVideo.title} className="h-full w-full object-cover" />
                    ) : (
                      <div className="h-full w-full bg-muted" />
                    )}
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition group-hover:opacity-100">
                      <Play className="h-5 w-5 text-white" />
                    </div>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <p className="line-clamp-2 text-sm font-medium text-foreground transition group-hover:text-primary">
                      {nextVideo.title || nextVideo.name}
                    </p>
                    {nextVideo.channel_name && (
                      <p className="mt-1 text-xs text-muted-foreground">@{nextVideo.channel_name}</p>
                    )}
                  </div>
                  <SkipForward className="h-4 w-4 shrink-0 text-muted-foreground transition group-hover:text-primary" />
                </button>
              </div>
            )}

            <div className="mt-4 flex flex-wrap gap-2">
              <a
                href={`https://odysee.com/${claim.name}:${claim.claim_id}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-card/60 px-3 py-1.5 font-mono text-[11px] uppercase tracking-widest text-muted-foreground transition-smooth hover:border-primary/40 hover:text-primary"
              >
                Open on Odysee →
              </a>
            </div>
          </div>
        </article>
      )}
    </div>
  );
}
