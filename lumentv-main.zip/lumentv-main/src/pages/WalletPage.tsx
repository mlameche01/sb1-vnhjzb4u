import { useEffect, useMemo, useState } from "react";
import { ArrowDownUp, Wallet, AlertCircle, RefreshCw, Loader2, Info } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";
import { useTokenBalances } from "@/hooks/useTokenBalances";
import {
  ERC20_TOKENS,
  NATIVE_TOKEN,
  XSWAP_APOTHEM,
  toUnits,
  fromUnits,
  getAmountsOut,
  getErc20Allowance,
  approveErc20,
  swapExactETHForTokens,
  swapExactTokensForETH,
} from "@/lib/evm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";

const ROUTER_ADDRESS = XSWAP_APOTHEM.router;
const WXDC_ADDRESS = XSWAP_APOTHEM.wxdc;
const SLIPPAGE_BPS = 50n; // 0.5%

type SwapKey = "TXDC" | keyof typeof ERC20_TOKENS;
const SWAP_TOKENS: Record<SwapKey, { symbol: string; decimals: number; address?: string; native?: boolean }> = {
  TXDC: { symbol: NATIVE_TOKEN.symbol, decimals: NATIVE_TOKEN.decimals, native: true },
  DZD: { ...ERC20_TOKENS.DZD },
};

export default function WalletPage() {
  const { account, balance, connecting, error, connect, disconnect, refreshBalance } = useWallet();
  const { balances, loading: loadingBalances, refresh } = useTokenBalances(account);

  const [from, setFrom] = useState<SwapKey>("DZD");
  const [to, setTo] = useState<SwapKey>("TXDC");
  const [amount, setAmount] = useState<string>("");
  const [estimatedOut, setEstimatedOut] = useState<string>("");
  const [quoting, setQuoting] = useState(false);
  const [swapping, setSwapping] = useState(false);

  const fromToken = SWAP_TOKENS[from];
  const toToken = SWAP_TOKENS[to];

  const path = useMemo(() => {
    const a = fromToken.native ? WXDC_ADDRESS : (fromToken.address as string);
    const b = toToken.native ? WXDC_ADDRESS : (toToken.address as string);
    return [a, b];
  }, [fromToken, toToken]);

  function balanceOf(key: SwapKey): string {
    if (SWAP_TOKENS[key].native) return balance ?? "—";
    return (balances as Record<string, string | undefined>)[key] ?? "—";
  }

  function flip() {
    setFrom(to);
    setTo(from);
    setAmount("");
    setEstimatedOut("");
  }

  // Live quote via router.getAmountsOut
  useEffect(() => {
    let cancelled = false;
    async function run() {
      if (!amount || Number(amount) <= 0 || from === to) {
        setEstimatedOut("");
        return;
      }
      try {
        setQuoting(true);
        const amountIn = toUnits(amount, fromToken.decimals);
        const amounts = await getAmountsOut(ROUTER_ADDRESS, amountIn, path);
        const out = amounts[amounts.length - 1];
        if (!cancelled) setEstimatedOut(fromUnits(out, toToken.decimals, 6));
      } catch {
        if (!cancelled) setEstimatedOut("");
      } finally {
        if (!cancelled) setQuoting(false);
      }
    }
    const t = setTimeout(run, 250);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [amount, from, to, path, fromToken.decimals, toToken.decimals]);

  async function handleSwap() {
    if (!account) return;
    if (!amount || Number(amount) <= 0) {
      toast({ title: "Enter an amount", variant: "destructive" });
      return;
    }
    if (from === to) {
      toast({ title: "Pick two different tokens", variant: "destructive" });
      return;
    }
    setSwapping(true);
    try {
      const amountIn = toUnits(amount, fromToken.decimals);
      const amounts = await getAmountsOut(ROUTER_ADDRESS, amountIn, path);
      const expectedOut = amounts[amounts.length - 1];
      const amountOutMin = (expectedOut * (10000n - SLIPPAGE_BPS)) / 10000n;
      const deadline = BigInt(Math.floor(Date.now() / 1000) + 60 * 10);

      let txHash: string;
      if (fromToken.native) {
        // TXDC -> DZD
        txHash = await swapExactETHForTokens({
          router: ROUTER_ADDRESS,
          amountInWei: amountIn,
          amountOutMin,
          path,
          to: account,
          deadline,
          from: account,
        });
      } else {
        // DZD -> TXDC : check allowance, approve if needed, then swap
        const allowance = await getErc20Allowance(
          fromToken.address as string,
          account,
          ROUTER_ADDRESS,
        );
        if (allowance < amountIn) {
          toast({ title: "Approval required", description: "Please confirm the approval tx in your wallet." });
          await approveErc20(fromToken.address as string, ROUTER_ADDRESS, amountIn, account);
          // small delay to let the node see the approval
          await new Promise((r) => setTimeout(r, 1500));
        }
        txHash = await swapExactTokensForETH({
          router: ROUTER_ADDRESS,
          amountIn,
          amountOutMin,
          path,
          to: account,
          deadline,
          from: account,
        });
      }
      toast({
        title: "Swap submitted",
        description: txHash.slice(0, 10) + "…" + txHash.slice(-6),
      });
      setAmount("");
      setEstimatedOut("");
      setTimeout(() => {
        refresh();
        refreshBalance();
      }, 4000);
    } catch (err) {
      toast({
        title: "Swap failed",
        description: (err as Error).message || "Unknown error",
        variant: "destructive",
      });
    } finally {
      setSwapping(false);
    }
  }

  const tokens: SwapKey[] = useMemo(() => Object.keys(SWAP_TOKENS) as SwapKey[], []);

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 md:px-8 md:py-10">
      <header className="mb-8">
        <div className="mb-2 flex items-center gap-2">
          <Wallet className="h-5 w-5 text-primary text-glow" />
          <span className="font-mono text-xs uppercase tracking-widest text-primary">
            Web3 wallet
          </span>
        </div>
        <h1 className="font-display text-3xl font-bold tracking-tight md:text-4xl">
          Wallet & Swap
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Connect your EVM wallet on XDC Apothem Testnet to view your TXDC (native) and DZD
          balances and swap between them via XSwap V2.
        </p>
      </header>

      {/* Connection */}
      <section className="mb-6 rounded-xl border border-border/60 bg-gradient-card p-5">
        {error && (
          <div className="mb-3 flex items-center gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            <AlertCircle className="h-4 w-4" />
            {error}
          </div>
        )}
        {!account ? (
          <Button
            onClick={connect}
            disabled={connecting}
            className="bg-gradient-primary text-primary-foreground shadow-glow-sm hover:shadow-glow"
          >
            {connecting ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Wallet className="mr-2 h-4 w-4" />
            )}
            {connecting ? "Connecting..." : "Connect wallet"}
          </Button>
        ) : (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                Connected
              </p>
              <p className="truncate font-mono text-sm text-primary">{account}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                Native: <span className="font-mono text-foreground">{balance ?? "—"} TXDC</span>
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  refresh();
                  refreshBalance();
                }}
                disabled={loadingBalances}
              >
                <RefreshCw className={`mr-2 h-3.5 w-3.5 ${loadingBalances ? "animate-spin" : ""}`} />
                Refresh
              </Button>
              <Button variant="ghost" size="sm" onClick={disconnect}>
                Disconnect
              </Button>
            </div>
          </div>
        )}
      </section>

      {/* Balances */}
      <section className="mb-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
        {tokens.map((key) => {
          const t = SWAP_TOKENS[key];
          return (
            <div
              key={key}
              className="rounded-xl border border-border/60 bg-card/40 p-4 transition-smooth hover:border-primary/40"
            >
              <div className="mb-1 flex items-center justify-between">
                <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
                  {t.symbol}
                  {t.native && (
                    <span className="ml-1 text-muted-foreground">· native</span>
                  )}
                </span>
                {t.address ? (
                  <a
                    href={`https://testnet.xdcscan.com/address/${t.address}`}
                    target="_blank"
                    rel="noreferrer"
                    className="font-mono text-[10px] text-muted-foreground hover:text-primary"
                    title={t.address}
                  >
                    {t.address.slice(0, 6)}…{t.address.slice(-4)}
                  </a>
                ) : (
                  <span className="font-mono text-[10px] text-muted-foreground">XDC Apothem</span>
                )}
              </div>
              <p className="font-display text-2xl font-bold tracking-tight">
                {account ? balanceOf(key) : "—"}
              </p>
            </div>
          );
        })}
      </section>

      {/* Swap */}
      <section className="rounded-xl border border-border/60 bg-gradient-card p-5 shadow-card">
        <div className="mb-4 flex items-center gap-2">
          <ArrowDownUp className="h-4 w-4 text-primary" />
          <h2 className="font-display text-lg font-semibold">Swap</h2>
        </div>

        <div className="mb-4 flex items-start gap-2 rounded-lg border border-primary/30 bg-primary/5 p-3 text-xs text-muted-foreground">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          <span>
            Powered by XSwap V2 on XDC Apothem · Router{" "}
            <span className="font-mono">{ROUTER_ADDRESS.slice(0, 6)}…{ROUTER_ADDRESS.slice(-4)}</span>{" "}
            · Slippage 0.5%
          </span>
        </div>

        <div className="space-y-3">
          {/* From */}
          <div className="rounded-lg border border-border/60 bg-background/50 p-3">
            <div className="mb-1 flex items-center justify-between">
              <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                From
              </span>
              <span className="font-mono text-[11px] text-muted-foreground">
                Balance: {balanceOf(from)}
              </span>
            </div>
            <div className="flex gap-2">
              <Input
                type="number"
                inputMode="decimal"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.0"
                className="border-0 bg-transparent text-2xl font-display font-bold focus-visible:ring-0"
              />
              <select
                value={from}
                onChange={(e) => {
                  const v = e.target.value as SwapKey;
                  setFrom(v);
                  if (v === to) setTo(from);
                }}
                className="rounded-md border border-border/60 bg-card/60 px-3 font-mono text-sm focus:border-primary focus:outline-none"
              >
                {tokens.map((k) => (
                  <option key={k} value={k}>
                    {SWAP_TOKENS[k].symbol}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-center">
            <button
              type="button"
              onClick={flip}
              className="rounded-full border border-border/60 bg-card/80 p-2 text-muted-foreground transition-smooth hover:border-primary hover:text-primary"
            >
              <ArrowDownUp className="h-4 w-4" />
            </button>
          </div>

          {/* To */}
          <div className="rounded-lg border border-border/60 bg-background/50 p-3">
            <div className="mb-1 flex items-center justify-between">
              <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                To (estimated)
              </span>
              <span className="font-mono text-[11px] text-muted-foreground">
                Balance: {balanceOf(to)}
              </span>
            </div>
            <div className="flex gap-2">
              <div className="flex h-10 flex-1 items-center px-3 text-2xl font-display font-bold text-foreground/80">
                {quoting ? (
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                ) : (
                  estimatedOut || "0.0"
                )}
              </div>
              <select
                value={to}
                onChange={(e) => {
                  const v = e.target.value as SwapKey;
                  setTo(v);
                  if (v === from) setFrom(to);
                }}
                className="rounded-md border border-border/60 bg-card/60 px-3 font-mono text-sm focus:border-primary focus:outline-none"
              >
                {tokens.map((k) => (
                  <option key={k} value={k}>
                    {SWAP_TOKENS[k].symbol}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <Button
            onClick={handleSwap}
            disabled={!account || !amount || swapping || from === to}
            className="w-full bg-gradient-primary text-primary-foreground shadow-glow-sm hover:shadow-glow"
          >
            {swapping ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Swapping…
              </>
            ) : !account ? (
              "Connect wallet first"
            ) : from === to ? (
              "Pick two different tokens"
            ) : (
              `Swap ${from} → ${to}`
            )}
          </Button>
        </div>
      </section>
    </div>
  );
}
