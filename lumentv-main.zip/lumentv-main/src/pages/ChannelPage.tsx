import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, AlertCircle, Radio, User, Heart } from "lucide-react";
import {
  resolveChannel,
  getChannelVideos,
  parseChannelSlug,
  Claim,
  thumbnail,
} from "@/lib/lbry";
import VideoCard, { VideoCardSkeleton } from "@/components/VideoCard";
import { Button } from "@/components/ui/button";
import { useFavorites } from "@/hooks/useFavorites";
import { cn } from "@/lib/utils";

export default function ChannelPage() {
  const { slug } = useParams<{ slug: string }>();
  const [channel, setChannel] = useState<Claim | null>(null);
  const [videos, setVideos] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { isFavorite, toggle } = useFavorites();
  const favorited = slug ? isFavorite(slug) : false;

  useEffect(() => {
    if (!slug) return;
    const parsed = parseChannelSlug(slug);
    if (!parsed) {
      setError("Invalid channel URL");
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);
    setChannel(null);
    setVideos([]);

    const url = `lbry://${parsed.name}#${parsed.id}`;
    resolveChannel(url)
      .then(async (ch) => {
        if (cancelled) return;
        setChannel(ch);
        // Use the resolved full claim_id (the URL may contain only a short id)
        const fullId = ch?.claim_id || parsed.id;
        const vids = await getChannelVideos(fullId, 1, 30);
        if (cancelled) return;
        setVideos(vids);
      })
      .catch((err) => {
        if (!cancelled) setError(err.message || "Failed to load channel");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [slug]);

  const channelThumb = channel?.thumbnail_url ? thumbnail(channel.thumbnail_url) : "";

  return (
    <div className="mx-auto max-w-[1600px] px-4 py-6 md:px-8 md:py-8">
      <Link
        to="/"
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-smooth hover:text-primary"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to trending
      </Link>

      {error && (
        <div className="mb-6 flex items-center gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          <AlertCircle className="h-4 w-4" />
          <span>{error}</span>
        </div>
      )}

      <header className="mb-8 flex flex-col gap-4 rounded-xl border border-border/60 bg-card/40 p-5 sm:flex-row sm:items-center">
        {channelThumb ? (
          <img
            src={channelThumb}
            alt={channel?.channel_name || channel?.name}
            className="h-20 w-20 rounded-full border border-primary/30 object-cover shadow-glow-sm"
          />
        ) : (
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-primary shadow-glow-sm">
            <User className="h-8 w-8 text-primary-foreground" />
          </div>
        )}
        <div className="flex-1">
          <div className="mb-1 flex items-center gap-2">
            <Radio className="h-4 w-4 text-primary text-glow" />
            <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
              LBRY channel
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold tracking-tight md:text-3xl">
            {channel?.title || channel?.name || (slug && decodeURIComponent(slug).split(":")[0])}
          </h1>
          {channel?.description && (
            <p className="mt-2 line-clamp-3 max-w-2xl text-sm text-muted-foreground">
              {channel.description}
            </p>
          )}
          <p className="mt-2 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            {videos.length} video{videos.length === 1 ? "" : "s"}
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => {
            if (!slug) return;
            toggle({
              slug,
              name: `@${(channel?.channel_name || channel?.name || decodeURIComponent(slug).split(":")[0]).replace(/^@/, "")}`,
              title: channel?.title,
              thumbnail: channel?.thumbnail_url,
            });
          }}
          className={cn(
            "shrink-0 gap-2 self-start sm:self-center",
            favorited && "border-primary/60 text-primary shadow-glow-sm",
          )}
        >
          <Heart className={cn("h-4 w-4", favorited && "fill-primary")} />
          {favorited ? "In favorites" : "Add to favorites"}
        </Button>
      </header>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
        {loading
          ? Array.from({ length: 10 }).map((_, i) => <VideoCardSkeleton key={i} />)
          : videos.map((claim) => <VideoCard key={claim.claim_id} claim={claim} />)}
      </div>

      {!loading && !error && videos.length === 0 && (
        <div className="rounded-xl border border-border/60 bg-card/40 p-12 text-center">
          <p className="text-muted-foreground">No videos found on this channel.</p>
        </div>
      )}
    </div>
  );
}
