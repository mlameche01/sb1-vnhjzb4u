import { useEffect, useState, useCallback } from "react";
import {
  Flame,
  AlertCircle,
  RefreshCw,
  Search,
  Wallet,
  LogOut,
  RotateCcw,
  Star,
  MessageCircle,
  Upload,
} from "lucide-react";
import { getTrending, Claim } from "@/lib/lbry";
import VideoCard, { VideoCardSkeleton } from "@/components/VideoCard";
import { useWallet } from "@/hooks/useWallet";
import AIChatPanel from "@/components/AIChatPanel";
import WelcomePopup from "@/components/WelcomePopup"; // ← AJOUTÉ

const PAGE_SIZE = 30;
const XDC_TESTNET_CHAIN_ID = "0x33"; // 51 decimal

const DEFAULT_FAVORITE = {
  name: "المهدي المنتظر",
  handle: "@imarat-el-djazair",
  url: "https://lumentn.lovable.app/search?q=%D8%A7%D9%84%D9%85%D9%87%D8%AF%D9%8A%20%D8%A7%D9%84%D9%85%D9%86%D8%AA%D8%B8%D8%B1",
};

function shortAddr(addr: string) {
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`;
}

export default function Index() {
  const [claims, setClaims] = useState<Claim[]>([]);
  const [filtered, setFiltered] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [search, setSearch] = useState("");
  const [retryCount, setRetryCount] = useState(0);
  const [chatOpen, setChatOpen] = useState(false);

  const {
    account,
    balance,
    chainId,
    connecting,
    error: walletError,
    connect,
    disconnect,
    refreshBalance,
  } = useWallet();

  const isOnXDC = chainId === XDC_TESTNET_CHAIN_ID;

  const trendingTitles = claims
    .slice(0, 15)
    .map((c) => c.title || c.name)
    .filter(Boolean);

  const fetchVideos = useCallback(
    async (pageNum: number, append = false) => {
      append ? setLoadingMore(true) : setLoading(true);
      setError(null);
      try {
        const items = await getTrending(pageNum, PAGE_SIZE);
        setClaims((prev) => (append ? [...prev, ...items] : items));
        setHasMore(items.length === PAGE_SIZE);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Failed to load";
        setError(msg);
      } finally {
        append ? setLoadingMore(false) : setLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    fetchVideos(1, false);
    setPage(1);
  }, [fetchVideos, retryCount]);

  useEffect(() => {
    if (!search.trim()) {
      setFiltered(claims);
    } else {
      const q = search.toLowerCase();
      setFiltered(
        claims.filter(
          (c) =>
            c.title?.toLowerCase().includes(q) ||
            c.channel_name?.toLowerCase().includes(q)
        )
      );
    }
  }, [search, claims]);

  const handleLoadMore = async () => {
    const next = page + 1;
    setPage(next);
    await fetchVideos(next, true);
  };

  return (
    <>
      {/* ── Popup de bienvenue ── */}
      <WelcomePopup />

      <AIChatPanel
        open={chatOpen}
        onClose={() => setChatOpen(false)}
        trendingTitles={trendingTitles}
      />

      <div className="relative min-h-full">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-96 bg-gradient-radial" />

        <div className="relative mx-auto max-w-[1600px] px-4 py-6 md:px-8 md:py-10">

          {/* ── Header ── */}
          <header className="mb-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">

              {/* Titre */}
              <div>
                <div className="mb-2 flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary text-glow" />
                  <span className="font-mono text-xs uppercase tracking-widest text-primary">
                    Trending now
                  </span>
                </div>
                <h1 className="font-display text-3xl font-bold tracking-tight md:text-5xl">
                  Lumen TN,{" "}
                  <span className="text-primary text-glow">المحتوى العربي</span>.
                </h1>
                <p className="mt-2 max-w-2xl text-sm text-muted-foreground md:text-base">
                  Stream what's hot on the LBRY peer-to-peer network. No accounts.
                  No algorithms tracking you. Just video.
                </p>
              </div>

              {/* Wallet block */}
              <div className="flex shrink-0 flex-col items-end gap-2">
                {account ? (
                  <>
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium ${
                        isOnXDC
                          ? "border-green-500/40 bg-green-500/10 text-green-400"
                          : "border-yellow-500/40 bg-yellow-500/10 text-yellow-400"
                      }`}
                    >
                      <span
                        className={`h-1.5 w-1.5 rounded-full ${
                          isOnXDC ? "bg-green-400" : "bg-yellow-400"
                        }`}
                      />
                      {isOnXDC ? "XDC Apothem" : "Mauvais réseau"}
                    </span>

                    {balance !== null && (
                      <div className="flex items-center gap-1.5">
                        <span className="rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-mono font-medium text-primary">
                          {balance} TXDC
                        </span>
                        <button
                          onClick={refreshBalance}
                          title="Rafraîchir le solde"
                          className="rounded-full border border-border/60 bg-card/60 p-1 text-muted-foreground transition hover:border-primary/60 hover:text-primary"
                        >
                          <RotateCcw className="h-3 w-3" />
                        </button>
                      </div>
                    )}

                    {isOnXDC && (
                      <a
                        href="https://faucet.apothem.network/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-muted-foreground underline underline-offset-2 transition hover:text-primary"
                      >
                        Obtenir des TXDC → Faucet
                      </a>
                    )}

                    <div className="flex items-center gap-2">
                      <span className="rounded-lg border border-border/60 bg-card/60 px-3 py-1.5 font-mono text-xs text-muted-foreground">
                        {shortAddr(account)}
                      </span>
                      <button
                        onClick={disconnect}
                        title="Déconnecter"
                        className="flex items-center gap-1.5 rounded-lg border border-border/60 bg-card/60 px-2.5 py-1.5 text-xs text-muted-foreground transition hover:border-destructive/60 hover:text-destructive"
                      >
                        <LogOut className="h-3.5 w-3.5" />
                        Déconnecter
                      </button>
                    </div>
                  </>
                ) : (
                  <button
                    onClick={connect}
                    disabled={connecting}
                    className="flex items-center gap-2 rounded-lg border border-border/60 bg-card/60 px-4 py-2 text-sm font-medium transition hover:border-primary/60 hover:text-primary disabled:opacity-50"
                  >
                    <Wallet className="h-4 w-4" />
                    {connecting ? "Connexion…" : "Connecter wallet"}
                  </button>
                )}

                {walletError && (
                  <p className="flex items-center gap-1.5 text-xs text-destructive">
                    <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                    {walletError}
                  </p>
                )}
              </div>
            </div>

            {/* ── Chaîne favorite + Upload Video (côte à côte) ── */}
            <div className="mt-5 flex flex-wrap gap-6">

              {/* Chaîne favorite */}
              <div>
                <div className="mb-2 flex items-center gap-2">
                  <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
                  <span className="font-mono text-xs uppercase tracking-widest text-yellow-400">
                    Chaîne favorite
                  </span>
                </div>
                <a
                  href={DEFAULT_FAVORITE.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group inline-flex items-center gap-3 rounded-xl border border-yellow-500/20 bg-yellow-500/5 px-4 py-2.5 transition hover:border-yellow-500/50 hover:bg-yellow-500/10"
                >
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-yellow-500/30 bg-yellow-500/10 text-sm font-bold text-yellow-400">
                    {DEFAULT_FAVORITE.name.charAt(0)}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-foreground transition group-hover:text-yellow-400">
                      {DEFAULT_FAVORITE.name}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {DEFAULT_FAVORITE.handle}
                    </span>
                  </div>
                  <span className="ml-2 text-xs text-muted-foreground transition group-hover:text-yellow-400">
                    →
                  </span>
                </a>
              </div>

              {/* Upload Video */}
              <div>
                <div className="mb-2 flex items-center gap-2">
                  <Upload className="h-3.5 w-3.5 text-primary" />
                  <span className="font-mono text-xs uppercase tracking-widest text-primary">
                    Upload Video
                  </span>
                </div>
                <a
                  href="https://odysee.com/@odysee.fr:8/presentation-odysee-sync-tool-ost:2"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group inline-flex items-center gap-3 rounded-xl border border-primary/20 bg-primary/5 px-4 py-2.5 transition hover:border-primary/50 hover:bg-primary/10"
                >
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-primary/30 bg-primary/10">
                    <Upload className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-foreground transition group-hover:text-primary">
                      Upload Video
                    </span>
                    <span className="text-xs text-muted-foreground">
                      Soumettre votre vidéo
                    </span>
                  </div>
                  <span className="ml-2 text-xs text-muted-foreground transition group-hover:text-primary">
                    →
                  </span>
                </a>
              </div>

            </div>
          </header>

          {/* ── Controls (search + actions) ── */}
          <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">

            {/* Search */}
            <div className="relative max-w-sm flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                placeholder="Filter videos or channels…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full rounded-lg border border-border/60 bg-card/60 py-2 pl-9 pr-4 text-sm outline-none ring-primary/40 transition placeholder:text-muted-foreground focus:ring-2 backdrop-blur"
              />
            </div>

            <div className="flex items-center gap-3">
              {!loading && (
                <span className="text-xs text-muted-foreground">
                  {search
                    ? `${filtered.length} result${filtered.length !== 1 ? "s" : ""}`
                    : `${claims.length} videos`}
                </span>
              )}

              {/* Bouton TICHOU IA */}
              <button
                onClick={() => setChatOpen(true)}
                className="flex items-center gap-1.5 rounded-lg border border-primary/40 bg-primary/5 px-3 py-2 text-xs font-medium text-primary transition hover:border-primary hover:bg-primary/10"
              >
                <MessageCircle className="h-3.5 w-3.5" />
                Tichou l'assistant IA
              </button>

              {/* Refresh */}
              <button
                onClick={() => setRetryCount((c) => c + 1)}
                disabled={loading}
                className="flex items-center gap-1.5 rounded-lg border border-border/60 bg-card/60 px-3 py-2 text-xs text-muted-foreground transition hover:border-primary/60 hover:text-primary disabled:opacity-50"
              >
                <RefreshCw
                  className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`}
                />
                Refresh
              </button>
            </div>
          </div>

          {/* ── Erreur vidéos ── */}
          {error && (
            <div className="mb-6 flex items-center justify-between gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
              <button
                onClick={() => setRetryCount((c) => c + 1)}
                className="rounded px-2 py-0.5 text-xs underline underline-offset-2 hover:opacity-80"
              >
                Retry
              </button>
            </div>
          )}

          {/* ── Grille vidéos ── */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
            {loading
              ? Array.from({ length: 10 }).map((_, i) => (
                  <VideoCardSkeleton key={i} />
                ))
              : filtered.map((claim) => (
                  <VideoCard key={claim.claim_id} claim={claim} />
                ))}
          </div>

          {/* ── État vide ── */}
          {!loading && !error && filtered.length === 0 && (
            <div className="rounded-xl border border-border/60 bg-card/40 p-12 text-center">
              <p className="text-muted-foreground">
                {search
                  ? `No videos match "${search}".`
                  : "No videos found right now. Try again shortly."}
              </p>
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="mt-3 text-xs text-primary hover:underline"
                >
                  Clear search
                </button>
              )}
            </div>
          )}

          {/* ── Load more ── */}
          {!loading && !error && hasMore && !search && (
            <div className="mt-8 flex justify-center">
              <button
                onClick={handleLoadMore}
                disabled={loadingMore}
                className="flex items-center gap-2 rounded-xl border border-border/60 bg-card/60 px-6 py-3 text-sm font-medium transition hover:border-primary/60 hover:text-primary disabled:opacity-50"
              >
                {loadingMore ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    Loading…
                  </>
                ) : (
                  "Load more videos"
                )}
              </button>
            </div>
          )}
        </div>

        {/* ── Bouton flottant chatbot ── */}
        {!chatOpen && (
          <button
            onClick={() => setChatOpen(true)}
            className="fixed bottom-6 right-6 z-20 flex items-center gap-2 rounded-full border border-primary/40 bg-card/90 px-4 py-3 text-sm font-medium text-primary shadow-lg shadow-primary/10 backdrop-blur"
          >
            <MessageCircle className="h-4 w-4" />
            <span>Tichou l'assistant IA</span>
          </button>
        )}
      </div>
    </>
  );
}
