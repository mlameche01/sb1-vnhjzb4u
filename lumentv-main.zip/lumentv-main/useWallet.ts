import { useState, useCallback } from "react";

const XDC_TESTNET = {
  chainId: "0x33", // 51 en decimal
  chainName: "XDC Apothem Testnet",
  nativeCurrency: { name: "TXDC", symbol: "TXDC", decimals: 18 },
  rpcUrls: ["https://erpc.apothem.network"],
  blockExplorerUrls: ["https://explorer.apothem.network"],
};

export function useWallet() {
  const [account, setAccount] = useState<string | null>(null);
  const [balance, setBalance] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchBalance = useCallback(async (addr: string) => {
    const raw = await (window as any).ethereum.request({
      method: "eth_getBalance",
      params: [addr, "latest"],
    });
    const wei = BigInt(raw);
    const txdc = Number(wei) / 1e18;
    setBalance(txdc.toFixed(4));
  }, []);

  const connect = useCallback(async () => {
    const eth = (window as any).ethereum;
    if (!eth) {
      setError("MetaMask non détecté. Installe l'extension.");
      return;
    }
    setConnecting(true);
    setError(null);
    try {
      // Demander connexion
      const accounts: string[] = await eth.request({ method: "eth_requestAccounts" });

      // Ajouter / switcher vers XDC Testnet
      try {
        await eth.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: XDC_TESTNET.chainId }],
        });
      } catch (switchErr: any) {
        if (switchErr.code === 4902) {
          await eth.request({
            method: "wallet_addEthereumChain",
            params: [XDC_TESTNET],
          });
        } else throw switchErr;
      }

      setAccount(accounts[0]);
      await fetchBalance(accounts[0]);
    } catch (err: any) {
      setError(err.message || "Connexion refusée");
    } finally {
      setConnecting(false);
    }
  }, [fetchBalance]);

  const disconnect = useCallback(() => {
    setAccount(null);
    setBalance(null);
  }, []);

  return { account, balance, connecting, error, connect, disconnect };
}
